package modelPackage;

public class StatisticCategoryModel {
    private String userName;
    private String categoryName;
    private int booksNb;
    public StatisticCategoryModel(String userName, String categoryName, int booksNb) {
        setUserName(userName);
        setCategoryName(categoryName);
        setBooksNb(booksNb);
    }
    public StatisticCategoryModel() {

    }
    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setBooksNb(int booksNb) {
        this.booksNb = booksNb;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public int getBooksNb() {
        return booksNb;
    }
    public String getUserName(){
        return userName;
    }
}
