package modelPackage;

public class StatisticCategoryTableModel {
    private String categoryName;
    private double percentage;
    public StatisticCategoryTableModel(String categoryName, double percentage) {
        setCategoryName(categoryName);
        setPercentage(percentage);
    }
    public String getCategoryName() {
        return categoryName;
    }
    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }
    public double getPercentage() {
        return percentage;
    }
    public void setPercentage(double percentage) {
        this.percentage = percentage;
    }
}
