package modelPackage;

public class BookRentalModel {
    private String title;
    private int copiesAvailable;
    public BookRentalModel(String title, Integer copiesAvailable) {
        setTitle(title);
        setCopiesAvailable(copiesAvailable);
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public void setCopiesAvailable(int copiesAvailable) {
        this.copiesAvailable = copiesAvailable;
    }
    public String getTitle() {
        return title;
    }
    public int getCopiesAvailable() {
        return copiesAvailable;
    }
}
