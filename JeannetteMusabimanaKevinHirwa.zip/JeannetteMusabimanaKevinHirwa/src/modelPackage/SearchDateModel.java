package modelPackage;

public class SearchDateModel {
    private String title;
    private String author;
    private String publishingHouse;

    public SearchDateModel(String title, String author, String publishingHouse) {
        setTitle(title);
        setAuthor(author);
        setPublishingHouse(publishingHouse);
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public void setAuthor(String author) {
        this.author = author;
    }
    public void setPublishingHouse(String publishingHouse) {
        this.publishingHouse = publishingHouse;
    }
    public String getTitle() {
        return title;
    }
    public String getAuthor() {
        return author;
    }
    public String getPublishingHouse() {
        return publishingHouse;
    }
}
