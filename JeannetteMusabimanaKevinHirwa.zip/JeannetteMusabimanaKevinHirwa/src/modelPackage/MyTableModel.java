package modelPackage;

import javax.swing.table.AbstractTableModel;
import java.util.Vector;
public class MyTableModel extends AbstractTableModel {
    private Vector<Vector<String>> data;
    private Vector<String> columnNames;

    public MyTableModel(Vector<Vector<String>> data, Vector<String> columnNames) {
        this.data = data;
        this.columnNames = columnNames;
    }

    @Override
    public int getRowCount() {
        return data.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.size();
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        return data.get(rowIndex).get(columnIndex);
    }

    @Override
    public String getColumnName(int index) {
        return columnNames.get(index);
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return false;
    }

}
