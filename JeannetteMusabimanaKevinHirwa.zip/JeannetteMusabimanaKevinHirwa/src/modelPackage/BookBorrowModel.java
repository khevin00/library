package modelPackage;

import java.time.LocalDate;

public class BookBorrowModel {
    private String title;
    private LocalDate borrowDate;

    public BookBorrowModel(LocalDate borrowDate, String title) {
        setTitle(title);
        setBorrowDate(borrowDate);
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getTitle() {
        return title;
    }
    public void setBorrowDate(LocalDate borrowDate) {
        this.borrowDate = borrowDate;
    }
    public LocalDate getBorrowDate() {
        return borrowDate;
    }
}
