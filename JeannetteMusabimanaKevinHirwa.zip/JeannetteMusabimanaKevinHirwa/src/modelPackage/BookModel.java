package modelPackage;

import java.time.LocalDate;

public class BookModel {
    private String title;
    private LocalDate publicationDate;
    private String authorFirstname;
    private String authorLastname;
    private String publishingName;

    public BookModel(String title, LocalDate publicationDate, String authorFirstname, String authorLastname, String publishingName){
        setTitle(title);
        setAuthorFirstname(authorFirstname);
        setAuthorLastname(authorLastname);
        setPublicationDate(publicationDate);
        setPublishingName(publishingName);
    }
    public void setTitle(String title){
        this.title = title;
    }
    public void setPublicationDate(LocalDate publicationDate){
        this.publicationDate = publicationDate;
    }
    public void setPublishingName(String publishingName){
        this.publishingName = publishingName;
    }
    public void setAuthorFirstname(String authorFirstname){
        this.authorFirstname = authorFirstname;
    }
    public void setAuthorLastname(String authorLastName){
        this.authorLastname = authorLastName;
    }
    public String getTitle(){
        return title;
    }
}
