package modelPackage;


public class PublishingHouseAdminModel {
    private Integer reference;
    private String publishingName;

    public PublishingHouseAdminModel(Integer reference, String publishingName) {
        setReference(reference);
        setPublishingName(publishingName);
    }

    public PublishingHouseAdminModel(Integer reference) {
    }

    public void setReference(Integer reference){
        this.reference = reference;
    }
    public void setPublishingName(String publishingName){
        this.publishingName = publishingName;
    }

    public Integer getReference() {
        return reference;
    }

    public String getPublishingName(){
        return publishingName;
    }

    @Override
    public String toString(){
        return getPublishingName();
    }
}