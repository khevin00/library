package modelPackage;

public class SearchAuthorModel {
    private String titleBook;
    private String publicationName;
    private String localityName;

    public SearchAuthorModel(String titleBook, String publicationName,String localityName) {
        setPublicationName(publicationName);
        setTitleBook(titleBook);
        setLocalityName(localityName);
    }
    public void setPublicationName(String publicationName){
        this.publicationName = publicationName;
    }
    public void setTitleBook(String titleBook){
        this.titleBook = titleBook;
    }
    public void setLocalityName(String localityName){
        this.localityName = localityName;
    }
    public String getPublicationName(){
        return publicationName;
    }
    public String getTitleBook(){
        return titleBook;
    }
    public String getLocalityName(){
        return localityName;
    }
}
