package modelPackage;

import java.time.LocalDate;

public class BookAdminModel {
    private String isbn;
    private LocalDate publicationDate;
    private String title;
    private Integer nbCopies;
    private String category;
    private Boolean isAvailable;
    private Boolean illustrated;
    private PublishingHouseAdminModel publicationHouse;
    private AuthorAdminModel authorWriting;

    public BookAdminModel(String isbn, LocalDate publicationDate, String title, Integer nbCopies, String category, Boolean isAvailable, Boolean illustrated, PublishingHouseAdminModel publicationHouse, AuthorAdminModel authorWriting ){
        setIsbn(isbn);
        setPublicationDate(publicationDate);
        setTitle(title);
        setNbCopies(nbCopies);
        setCategory(category);
        setIsAvailable(isAvailable);
        setIllustrated(illustrated);
        setPublicationHouse(publicationHouse);
        setAuthorWriting(authorWriting);

    }
    public BookAdminModel(String isbn, LocalDate publicationDate, String title, Integer nbCopies, Boolean isAvailable,  PublishingHouseAdminModel publicationHouse, AuthorAdminModel authorWriting ){
        this(isbn,publicationDate,title,nbCopies,null,isAvailable,null,publicationHouse,authorWriting);
    }

    public BookAdminModel() {

    }

    public void setIsbn(String isbn){
        this.isbn = isbn;
    }

    public void setPublicationDate(LocalDate publicationDate){
        this.publicationDate = publicationDate;
    }

    public void setTitle(String title) {
        this.title = title;
    }
    public void setNbCopies(Integer nbCopies){
        this.nbCopies = nbCopies;
    }
    public void setCategory(String category){
        this.category = category;
    }

    public void setIsAvailable(Boolean isAvailable){
        this.isAvailable = isAvailable;
    }
    public void setIllustrated(Boolean illustrated) {
        this.illustrated = illustrated;
    }

    public LocalDate getPublicationDate() {
        return publicationDate;
    }

    public String getTitle() {
        return title;
    }
    public Integer getNbCopies() {
        return nbCopies;
    }
    public String getCategory() {
        return category;
    }
    public Boolean getIsAvailable() {
        return isAvailable;
    }
    public Boolean getIllustrated() {
        return illustrated;
    }

    @Override
    public  String toString(){
        return title;

    }

    public void setPublicationHouse(PublishingHouseAdminModel publicationHouse) {
        this.publicationHouse = publicationHouse;
    }

    public PublishingHouseAdminModel getPublicationHouse(){
        return publicationHouse;
    }
    public void setAuthorWriting(AuthorAdminModel authorWriting){
        this.authorWriting = authorWriting;
    }
    public AuthorAdminModel getAuthorWriting(){
        return authorWriting;
    }

    public String getIsbn() {
        return isbn;
    }
}