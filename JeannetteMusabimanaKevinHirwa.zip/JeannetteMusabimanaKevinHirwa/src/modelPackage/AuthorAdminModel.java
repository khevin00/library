package modelPackage;

import java.time.LocalDate;

public class AuthorAdminModel {
    private Integer reference;
    private String firstname;
    private String lastname;
    private LocalDate dateOfBirth;
    private String nationality;
    private LocalDate deathDate;

    public AuthorAdminModel(Integer reference, String firstname, String lastname, LocalDate dateOfBirth, String nationality, LocalDate deathDate) {
        setReference(reference);
        setFirstname(firstname);
        setLastname(lastname);
        setDateOfBirth(dateOfBirth);
        setNationality(nationality);
        setDeathDate(deathDate);
    }
    public AuthorAdminModel() {

    }

    public void setReference(Integer reference) {
        this.reference = reference;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }


    public Integer getReference() {
        return reference;
    }

    public String getFirstname() {
        return firstname;
    }

    public String getLastname() {
        return lastname;
    }
    public String getNationality(){
        return nationality;
    }
    @Override
    public String toString() {
        return getLastname() + " " + getFirstname();
    }

    public void setDeathDate(LocalDate deathDate) {
        this.deathDate = deathDate;
    }
}