package modelPackage;

import java.time.LocalDate;

public class BorrowDisplayModel {
    private String username;
    private String titleBook;
    private String authorName;
    private LocalDate borrowDate;
    private String publishingName;

    public BorrowDisplayModel(String username, String titleBook, String authorName, LocalDate borrowDate, String publishingName) {
        setUserName(username);
        setTitleBook(titleBook);
        setAuthorName(authorName);
        setBorrowDate(borrowDate);
        setPublishingName(publishingName);
    }
    public void setUserName(String username) {
        this.username = username;
    }
    public void setTitleBook(String titleBook) {
        this.titleBook = titleBook;
    }
    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }
    public void setBorrowDate(LocalDate borrowDate) {
        this.borrowDate = borrowDate;
    }
    public void setPublishingName(String publishingName) {
        this.publishingName = publishingName;
    }
    public String getUsername() {
        return username;
    }
    public String getTitleBook() {
        return titleBook;
    }
    public String getAuthorName() {
        return authorName;
    }
    public LocalDate getBorrowDate() {
        return borrowDate;
    }
    public String getPublishingName() {
        return publishingName;
    }
}
