package dataAccesPackage;

import exceptionPackage.ConnectionException;
import exceptionPackage.ExistException;

import java.sql.SQLException;
import java.time.LocalDate;

public interface ConnectionDAOInterface {
    Boolean userPresent(String username, String password) throws ConnectionException;
    boolean isUsernameExist(String username) throws ConnectionException;
    boolean isFullNameExist(String lastname, String firstname) throws ConnectionException;
    boolean registerUser(String lastname, String firstname, LocalDate birthdate, String username, String password) throws ExistException, ConnectionException;

}
