package dataAccesPackage;

import java.util.ArrayList;

import exceptionPackage.ConnectionException;
import exceptionPackage.InputException;
import modelPackage.BookModel;

public interface BookDAOInterface {
    ArrayList<BookModel> searchBooks(String bookTitle, String authorName, Integer publishingYear) throws InputException;

}
