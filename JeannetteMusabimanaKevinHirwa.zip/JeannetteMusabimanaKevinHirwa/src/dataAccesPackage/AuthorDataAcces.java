package dataAccesPackage;

import exceptionPackage.ErrorAccesException;
import modelPackage.BorrowDisplayModel;
import modelPackage.SearchAuthorModel;
import modelPackage.SearchDateModel;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;

public class AuthorDataAcces implements AuthorDAOInterface {
    public ArrayList<String> getAllAuthorsNames() throws ErrorAccesException {
        String query = "SELECT CONCAT(firstname, ' ', lastname) as author from author";
        ArrayList<String> authorNames = new ArrayList<>();

        try {
            Connection connection = SingletonConnexion.getInstance();
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet data = preparedStatement.executeQuery();
            while (data.next()) {
                String fullName = data.getString("author");
                authorNames.add(fullName);
            }
            return authorNames;
        } catch (SQLException exception) {
            throw new ErrorAccesException("ECHEC de remplissage de la combobox de l'auteur.");
        }
    }

    public ArrayList<SearchAuthorModel> getInformationsAboutAuthor(String fullName) throws ErrorAccesException {
        String query = "SELECT a.firstname, b.title, p.publishingName, CONCAT(l.postalCode,' à ',l.name) as name " +
                "FROM author a " +
                "INNER JOIN book b ON a.reference = b.authorWriting " +
                "INNER JOIN publishingHouse p ON b.publicationHouse = p.reference " +
                "INNER JOIN locality l ON a.locality = l.reference " +
                "WHERE CONCAT(a.firstname, ' ', a.lastname) = ?";
        try {
            Connection connection = SingletonConnexion.getInstance();
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1,fullName);
            ResultSet data = statement.executeQuery();
            ArrayList<SearchAuthorModel> authorModels = new ArrayList<>();

            while(data.next()) {
                SearchAuthorModel authorInfos = new SearchAuthorModel(
                        data.getString("title"),
                        data.getString("publishingName"),
                        data.getString("name")
                );
                authorModels.add(authorInfos);
            }
            return authorModels;
        } catch (SQLException exception) {
            throw new ErrorAccesException("ECHEC de récupération des informations de l'auteur.");
        }
    }

    @Override
    public ArrayList<SearchDateModel> getInformationsWithDate(LocalDate firstDate, LocalDate secondDate) throws ErrorAccesException {
        String query = "SELECT b.title, CONCAT(a.firstname,' ',a.lastname) as author, b.title, p.publishingName "+
        "from book b "+
        "inner join author a on b.authorWriting = a.reference "+
        "inner join publishinghouse p on b.publicationHouse = p.reference "+
        "where b.publicationDate between ? and ? order by b.title";
        try{
            Connection connection = SingletonConnexion.getInstance();
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setDate(1, Date.valueOf(firstDate));
            statement.setDate(2, Date.valueOf(secondDate));
            ResultSet data = statement.executeQuery();
            ArrayList<SearchDateModel> dateModels = new ArrayList<>();
            while(data.next()) {
                SearchDateModel searchDate = new SearchDateModel(
                        data.getString("title"),
                        data.getString("author"),
                        data.getString("publishingName")
                );
                dateModels.add(searchDate);
            }
            return dateModels;
        }catch (SQLException exception) {
            throw new ErrorAccesException("ECHEC de recupération des informations des livres.");
        }
    }
    public ArrayList<BorrowDisplayModel> displayBorrowUserSearch(String user) throws ErrorAccesException {
        String query = "select u.userName, b.title, CONCAT(a.firstname,' ',a.lastname) as 'author', borrowDate, p.publishingName from user u\n" +
                "inner join borrow bo on userName = bo.userBorrower\n" +
                "inner join  book b on b.isbn = bo.bookCurrentBorrowing\n" +
                "inner join author a on a.reference = b.authorWriting\n" +
                "inner join publishinghouse p on p.reference = b.publicationHouse\n" +
                "where bo.isCurrentlyRented = '1' and bo.userBorrower = ? order by b.title";
        try {
            Connection connection = SingletonConnexion.getInstance();
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1,user);
            ResultSet data = preparedStatement.executeQuery();
            ArrayList<BorrowDisplayModel> search = new ArrayList<>();

            while (data.next()) {
                BorrowDisplayModel infoSearch = new BorrowDisplayModel(
                        data.getString("userName"),
                        data.getString("title"),
                        data.getString("author"),
                        data.getDate("borrowDate").toLocalDate(),
                        data.getString("publishingName")
                );
                search.add(infoSearch);
            }
            return search;
        } catch (SQLException exception) {
            throw new ErrorAccesException("ECHEC de recherche sur les informations de livre loué");
        }
    }

    public ArrayList<String> getAllUsers() throws ErrorAccesException{
        ArrayList<String> users = new ArrayList<>();
        String sqlInstruction = "select userName from user";
        try {
            Connection connection = SingletonConnexion.getInstance();
            PreparedStatement preparedStatement = connection.prepareStatement(sqlInstruction);
            ResultSet data = preparedStatement.executeQuery();

            while(data.next()) {
                String userName = data.getString("userName");
                users.add(userName);
            }

        } catch (SQLException exception) {
            throw new ErrorAccesException("Erreur de récupération des informations de l'utilisateur.");
        }
        return users;
    }

}
