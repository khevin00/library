package dataAccesPackage;

import exceptionPackage.ConnectionException;

import java.sql.SQLException;
import java.time.LocalDate;

public interface AdminDAOInteface {
    Boolean adminPresent(String username, String password) throws ConnectionException;

}
