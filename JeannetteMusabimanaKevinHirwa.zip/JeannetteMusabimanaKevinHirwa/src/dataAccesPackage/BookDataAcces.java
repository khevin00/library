package dataAccesPackage;

import exceptionPackage.InputException;
import modelPackage.BookModel;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

public  class BookDataAcces implements BookDAOInterface{
    @Override
    public ArrayList<BookModel> searchBooks(String bookTitle, String authorName, Integer publishingYear) throws InputException{
        try{
            Connection connection = SingletonConnexion.getInstance();
            String requeteSQL = "select b.title, b.publicationDate, a.firstname, a.lastname, p.publishingName from book b " +
                    "inner join author a on (b.authorWriting = a.reference) " +
                    "inner join publishingHouse p on (b.publicationHouse = p.reference) " +
                    "where b.title = ?";

            PreparedStatement statement = connection.prepareStatement(requeteSQL);
            statement.setString(1,bookTitle);
            ResultSet data = statement.executeQuery();
            ArrayList<BookModel> searchBook = new ArrayList<>();

            while(data.next()){
                BookModel book = new BookModel(
                        data.getString("title"),
                        data.getDate("publicationDate").toLocalDate(),
                        data.getString("firstname"),
                        data.getString("lastname"),
                        data.getString("publishingName")
                );
                searchBook.add(book);
            }
            return searchBook;
        }catch(SQLException exception){
            throw new InputException(exception.getMessage());
        }
    }
}
