package dataAccesPackage;

import exceptionPackage.ErrorAccesException;
import modelPackage.BookModel;


import java.util.ArrayList;
import java.util.List;

public interface DisplayBookDAOInteface {
    List<String> getAllBooks() throws ErrorAccesException;
    BookModel getBookByTitle(String title) throws ErrorAccesException;
    ArrayList<String> getAllAuthorsNames() throws ErrorAccesException;
    ArrayList<String> getAllPublishingNames() throws ErrorAccesException;
}
