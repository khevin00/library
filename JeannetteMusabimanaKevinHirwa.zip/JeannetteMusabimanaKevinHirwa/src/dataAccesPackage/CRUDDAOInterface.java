package dataAccesPackage;

import exceptionPackage.BookAlreadyExistsException;
import exceptionPackage.ErrorAccesException;
import modelPackage.AuthorAdminModel;
import modelPackage.BookAdminModel;
import modelPackage.PublishingHouseAdminModel;

import java.util.ArrayList;

public interface CRUDDAOInterface {
    ArrayList<BookAdminModel> getAllBooks() throws ErrorAccesException;

    void addBook(BookAdminModel book) throws ErrorAccesException;

    void alterBook(BookAdminModel book) throws ErrorAccesException;

    void removeBook(String isbn) throws ErrorAccesException;

    boolean checkIsbnValidity(String isbn) throws ErrorAccesException, BookAlreadyExistsException;

    ArrayList<PublishingHouseAdminModel> getAllPublishingHouses() throws ErrorAccesException;

    ArrayList<AuthorAdminModel> getAllAuthors() throws ErrorAccesException;

    boolean ckeckTitleExist(String title) throws BookAlreadyExistsException;
}
