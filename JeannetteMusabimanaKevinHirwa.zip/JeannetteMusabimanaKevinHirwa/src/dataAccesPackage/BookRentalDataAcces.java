package dataAccesPackage;

import exceptionPackage.ErrorAccesException;
import modelPackage.BookBorrowModel;
import modelPackage.BookRentalModel;
import modelPackage.BorrowDisplayModel;
import modelPackage.SearchAuthorModel;
import org.mindrot.jbcrypt.BCrypt;

import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class BookRentalDataAcces implements BookRentalDAOInterface {
    public ArrayList<BookRentalModel> getAllBooks() throws ErrorAccesException {
        String query = "select title, nbCopies from book ORDER BY title ASC";
        ArrayList<BookRentalModel> booksNames = new ArrayList<>();

        try {
            Connection connection = SingletonConnexion.getInstance();
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet data = preparedStatement.executeQuery();
            while (data.next()) {
                String title = data.getString("title");
                Integer nbCopies = data.getInt("nbCopies");
                BookRentalModel book = new BookRentalModel(title, nbCopies);
                booksNames.add(book);
            }
            return booksNames;
        } catch (SQLException exception) {
            throw new ErrorAccesException("ECHEC de remplissage de la combobox de livres.");
        }
    }

    public boolean rentalBook(String title) throws ErrorAccesException {
        String query = "update book set nbCopies = nbCopies - 1 where title = ?";
        try {
            Connection connection = SingletonConnexion.getInstance();
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, title);
            return preparedStatement.executeUpdate() > 0;
        } catch (SQLException exception) {
            throw new ErrorAccesException("Rupture de stock ! Impossible de louer ce livre.");
        }
    }
    public void updateCurrentlyRented(String user, String isbn) throws ErrorAccesException {
        String query = "UPDATE borrow SET isCurrentlyRented = 0 WHERE bookCurrentBorrowing IN ( SELECT isbn FROM book\n" +
                " WHERE isbn = ?) AND userBorrower = ?";
        try {
            Connection connection = SingletonConnexion.getInstance();
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, isbn);
            preparedStatement.setString(2, user);
            int affectedRows = preparedStatement.executeUpdate();
            if (affectedRows == 0) {
                throw new ErrorAccesException("Aucun livre correspondant au titre n'a été trouvé pour être retourné.");
            }
        } catch (SQLException exception) {
            throw new ErrorAccesException("ERROR ! Impossible de mettre a jour l'actualisation de livre loué.");
        }
    }
    public void returnBook(String title) throws ErrorAccesException {
        String query = "update book set nbCopies = nbCopies + 1 where title = ?";
        try {
            Connection connection = SingletonConnexion.getInstance();
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, title);
            int affectedRows = preparedStatement.executeUpdate();
            if (affectedRows == 0) {
                throw new ErrorAccesException("Aucun livre correspondant au titre n'a été trouvé pour être retourné.");
            }
        } catch (SQLException exception) {
            throw new ErrorAccesException("ERROR ! Impossible de rendrer ce livre.");
        }
    }

    public String getISBN(String title) throws ErrorAccesException {
        String query = "select ISBN from book where title = ?";
        try{
            Connection connection = SingletonConnexion.getInstance();
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, title);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                return resultSet.getString("isbn");
            } else {
                return null;
            }
        } catch (SQLException exception) {
            throw new ErrorAccesException("ERROR ! Impossible de récuperer ISBN du livre ");
        }
    }

    public boolean bookAlreadyRented(String user, String title) throws ErrorAccesException {
        String isbn = getISBN(title);
        String query = "select * from borrow where bookCurrentBorrowing = ? and userBorrower = ? and isCurrentlyRented = 1";
        try{
            Connection connection = SingletonConnexion.getInstance();
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, isbn);
            preparedStatement.setString(2, user);
            ResultSet resultSet = preparedStatement.executeQuery();
            return resultSet.next();
        } catch (SQLException exception) {
            throw new ErrorAccesException("ERROR ! Impossible de vérifier si le livre est déjà emprunté");
        }
    }

    public void addBookInBorrow(String title, String user) throws ErrorAccesException {
        String query = "insert into borrow(borrowDate, isCurrentlyRented, bookCurrentBorrowing, userBorrower) values (?, ?, ?, ?)";
        try{
            Connection connection = SingletonConnexion.getInstance();
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDateTime now = LocalDateTime.now();
            preparedStatement.setDate(1, Date.valueOf(dtf.format(now)));
            preparedStatement.setInt(2, 1);
            String isbn = getISBN(title);
            preparedStatement.setString(3, isbn);
            preparedStatement.setString(4, user);
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected == 0) {
                throw new ErrorAccesException("Aucune ligne ajoutée, vérifiez les données.");
            }
        }catch (SQLException exception) {
            throw new ErrorAccesException("ERROR ! Impossible de louer ce livre");
        }
    }

    public ArrayList<BookBorrowModel> displayBorrowBook(String user) throws ErrorAccesException {
        String query = "select borrowDate, b.title from borrow\n" +
                "inner join book b on bookCurrentBorrowing = b.isbn\n" +
                "where userBorrower = ? and isCurrentlyRented = 1";

        try {
            Connection connection = SingletonConnexion.getInstance();
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1,user);
            ResultSet data = preparedStatement.executeQuery();
            ArrayList<BookBorrowModel> booksBorrows = new ArrayList<>();

            while (data.next()) {
                BookBorrowModel book = new BookBorrowModel(
                        data.getDate("borrowDate").toLocalDate(),
                        data.getString("title")
                );
                booksBorrows.add(book);
            }
            return booksBorrows;
        } catch (SQLException exception) {
            throw new ErrorAccesException("Echec de recherche de livres loués");
        }
    }
}
