package dataAccesPackage;

import exceptionPackage.BookCountException;
import modelPackage.StatisticCategoryModel;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

public class StatisticDataAcces implements StatisticDAOInterface {
    public Integer getBookCount(String user) throws BookCountException {
        int currentYear = LocalDate.now().getYear();
        String query = "SELECT userBorrower, COUNT(*) AS bookCount FROM borrow WHERE userBorrower = ? AND YEAR(borrowDate) = ? GROUP BY userBorrower ";
        try {
            Connection connection = SingletonConnexion.getInstance();
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, user);
            preparedStatement.setInt(2, currentYear);
            ResultSet data = preparedStatement.executeQuery();
            if (data.next()) {
                return data.getInt("bookCount");
            } else {
                return 0;
            }
        } catch (SQLException exception) {
            throw new BookCountException("Impossible de recuperer le nombre de livres loués par chaque utilisateur");
        }
    }
    public ArrayList<StatisticCategoryModel> getBorrowCountsByCategoryForUser(String user) throws BookCountException {
        String query = "SELECT u.userName, b.category, COUNT(*) AS bookCount\n" +
                "FROM borrow br\n" +
                "JOIN book b ON br.bookCurrentBorrowing = b.isbn\n" +
                "JOIN user u ON br.userBorrower = u.userName\n" +
                "where u.userName = ?\n" +
                "GROUP BY u.userName, b.category";
        try {
            Connection connection = SingletonConnexion.getInstance();
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, user);
            ResultSet data = preparedStatement.executeQuery();
            ArrayList<StatisticCategoryModel> booksData = new ArrayList<>();
            while (data.next()) {
                String userName = data.getString("userName");
                String category = data.getString("category");
                Integer booksNb = data.getInt("bookCount");
                StatisticCategoryModel dataUsers = new StatisticCategoryModel(userName,category, booksNb);
                booksData.add(dataUsers);
            }
            return booksData;
        } catch (SQLException exception) {
            throw new BookCountException("Impossible de recuperer le nombre de livres par catégorie loués par chaque utilisateur");
        }
    }
}

