package dataAccesPackage;

import exceptionPackage.ConnectionException;
import exceptionPackage.ExistException;
import org.mindrot.jbcrypt.BCrypt;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

public class ConnectionDataAcces implements ConnectionDAOInterface {
    @Override
    public Boolean userPresent(String username, String password) throws ConnectionException {
        String requeteSQL = "select * from user where userName = ?";
        try{
            Connection connection = SingletonConnexion.getInstance();
            PreparedStatement preparedStatement = connection.prepareStatement(requeteSQL);
            preparedStatement.setString(1, username);

            ResultSet data = preparedStatement.executeQuery();
            if(data.next()){
                String storedHash = data.getString("password");
                return BCrypt.checkpw(password, storedHash);
            }
            return false;
        } catch (SQLException exception) {
            throw new ConnectionException("Erreur lors de la vérification de l'utilisateur");
        }
    }
    public boolean isUsernameExist(String username) throws ConnectionException {
        String sql = "SELECT count(*) FROM user WHERE userName = ?";
        try {
            Connection connection = SingletonConnexion.getInstance();
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, username);
            ResultSet data = preparedStatement.executeQuery();
            data.next();
            return data.getInt(1) > 0;
        } catch (SQLException exception) {
            throw new ConnectionException("Erreur lors de la vérification du nom d'utilisateur");
        }
    }
    public boolean isFullNameExist(String lastname, String firstname) throws ConnectionException {
        String sql = "SELECT count(*) FROM user WHERE lastname = ? AND firstname = ?";
        try {
            Connection connection = SingletonConnexion.getInstance();
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, lastname);
            preparedStatement.setString(2, firstname);
            ResultSet data = preparedStatement.executeQuery();
            data.next();
            return data.getInt(1) > 0;
        } catch (SQLException exception) {
            throw new ConnectionException("Erreur lors de la vérification du nom complet");
        }
    }
    public boolean registerUser(String lastname, String firstname, LocalDate birthdate, String username, String password) throws ExistException, ConnectionException {
        if (isUsernameExist(username) || isFullNameExist(lastname, firstname)) {
            throw new ExistException("Utilisateur ou nom complet existe déjà.");
        }
        String sql = "INSERT INTO user (lastname, firstname, dateOfBirth, userName, password) VALUES (?, ?, ?, ?, ?)";
        try {
            Connection connection = SingletonConnexion.getInstance();
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, lastname);
            preparedStatement.setString(2, firstname);
            preparedStatement.setDate(3, java.sql.Date.valueOf(birthdate));
            preparedStatement.setString(4, username);
            String hashedPassword = BCrypt.hashpw(password, BCrypt.gensalt());
            preparedStatement.setString(5, hashedPassword);
            int affectedRows = preparedStatement.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException exception) {
            throw new ConnectionException("Erreur lors de l'enregistrement de l'utilisateur");
        }
    }
}
