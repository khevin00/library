package dataAccesPackage;

import exceptionPackage.BookNotFoundException;
import exceptionPackage.ErrorAccesException;
import modelPackage.BookModel;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

public class DisplayBookDataAcces implements DisplayBookDAOInteface{
    public List<String> getAllBooks() throws ErrorAccesException {
        List<String> titles = new ArrayList<>();
        String query = "SELECT title from book ORDER BY title ASC";
        try {
            Connection connection = SingletonConnexion.getInstance();
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet data = preparedStatement.executeQuery();
            while (data.next()) {
                titles.add(data.getString("title"));
            }
        } catch (SQLException exception) {
            throw new ErrorAccesException("Echec de récupération des livres");
        }
        return titles;
    }
    public BookModel getBookByTitle(String title) throws ErrorAccesException {
       String query = "SELECT b.title, b.publicationDate, a.firstname, a.lastname, p.publishingName from book b \n" +
               "inner join author a on b.authorWriting = a.reference\n" +
               "inner join publishinghouse p on b.publicationHouse = p.reference\n" +
               "where b.title = ?";
        try{
            Connection connection = SingletonConnexion.getInstance();
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, title);
            ResultSet data = preparedStatement.executeQuery();
            if(data.next()) {
                return new BookModel(
                        data.getString("title"),
                        data.getDate("publicationDate").toLocalDate(),
                        data.getString("firstname"),
                        data.getString("lastname"),
                        data.getString("publishingName")
                );
            }else{
                throw new BookNotFoundException("Livre introuvable");
            }
        }catch (SQLException | BookNotFoundException exception){
            throw new ErrorAccesException("ECHEC de remplissage automatique");
        }
    }
    public ArrayList<String> getAllAuthorsNames() throws ErrorAccesException{
        String query = "SELECT DISTINCT a.lastname, a.firstname FROM book b\n" +
                "right join author a on b.authorWriting = a.reference";
        ArrayList<String> authorsNames  = new ArrayList<>();
        try{
            Connection connection = SingletonConnexion.getInstance();
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet data = preparedStatement.executeQuery();

            while (data.next()) {
                String fullName = data.getString("lastname") + " " + data.getString("firstname");
                authorsNames.add(fullName);
            }
            return authorsNames;
        }catch (SQLException exception){
            throw new ErrorAccesException("ECHEC de remplissage de l'auteur");
        }
    }
    public ArrayList<String> getAllPublishingNames() throws ErrorAccesException{
        String query = "SELECT DISTINCT p.publishingName FROM book b\n"+
        "right join publishinghouse p on b.publicationHouse = p.reference";
        ArrayList<String> publishingNames  = new ArrayList<>();
        try{
            Connection connection = SingletonConnexion.getInstance();
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet data = preparedStatement.executeQuery();
            while (data.next()) {
                String fullName = data.getString("publishingName");
                publishingNames.add(fullName);
            }
            return publishingNames;
        }catch (SQLException exception){
            throw new ErrorAccesException("ECHEC de remplissage de la maison de publication");
        }
    }
}