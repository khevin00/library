package dataAccesPackage;

import exceptionPackage.BookCountException;
import modelPackage.StatisticCategoryModel;

import java.util.ArrayList;

public interface StatisticDAOInterface {
    Integer getBookCount(String user) throws BookCountException;
    ArrayList<StatisticCategoryModel> getBorrowCountsByCategoryForUser(String user) throws BookCountException;
}
