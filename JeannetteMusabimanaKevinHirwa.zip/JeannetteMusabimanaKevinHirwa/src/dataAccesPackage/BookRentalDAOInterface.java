package dataAccesPackage;

import exceptionPackage.ErrorAccesException;
import modelPackage.BookBorrowModel;
import modelPackage.BookRentalModel;
import modelPackage.BorrowDisplayModel;

import java.util.ArrayList;

public interface BookRentalDAOInterface {
    ArrayList<BookRentalModel> getAllBooks() throws ErrorAccesException;
    boolean rentalBook(String title) throws ErrorAccesException;
    void addBookInBorrow(String title, String user) throws ErrorAccesException;
    ArrayList<BookBorrowModel> displayBorrowBook(String user) throws ErrorAccesException;
    boolean bookAlreadyRented(String user, String title) throws ErrorAccesException;
    void returnBook(String isbn) throws ErrorAccesException;
    void updateCurrentlyRented(String user, String isbn) throws ErrorAccesException;
    String getISBN(String title) throws ErrorAccesException;

}
