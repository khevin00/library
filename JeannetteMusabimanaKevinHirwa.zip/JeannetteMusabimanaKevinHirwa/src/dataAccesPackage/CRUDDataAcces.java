package dataAccesPackage;

import exceptionPackage.*;
import modelPackage.*;
import java.sql.*;
import java.util.ArrayList;
import java.time.LocalDate;

public class  CRUDDataAcces implements CRUDDAOInterface {
    private Connection dataBaseAccess;

    @Override
    public ArrayList<BookAdminModel> getAllBooks() throws ErrorAccesException {
        BookAdminModel book;
        String category;
        Boolean illustrated;
        ArrayList<BookAdminModel> books = new ArrayList<>();
        String sql = "SELECT * FROM book";
        try {
            dataBaseAccess = SingletonConnexion.getInstance();
            PreparedStatement statement = dataBaseAccess.prepareStatement(sql);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                int publishingHouseRef = resultSet.getInt("publicationHouse");
                int authorRef = resultSet.getInt("authorWriting");
                PublishingHouseAdminModel publishingHouse = getPublishingHouseById(publishingHouseRef);
                AuthorAdminModel author = getAuthorById(authorRef);

                book = new BookAdminModel(resultSet.getString("isbn"),
                        resultSet.getDate("publicationDate").toLocalDate(),
                        resultSet.getString("title"),
                        resultSet.getInt("nbCopies"),
                        resultSet.getString("category"),
                        resultSet.getBoolean("isAvailable"),
                        resultSet.getBoolean("illustrated"),
                        publishingHouse,
                        author);

                category = resultSet.getString("category");
                if (!resultSet.wasNull()) {
                    book.setCategory(category);
                } else {
                    book.setCategory(null);
                }
                illustrated = resultSet.getBoolean("illustrated");
                if (!resultSet.wasNull()) {
                    book.setIllustrated(illustrated);
                } else {
                    book.setIllustrated(null);
                }
                books.add(book);
            }

        } catch (SQLException e) {
            throw new ErrorAccesException(e.getMessage());
        }
        return books;
    }

    private PublishingHouseAdminModel getPublishingHouseById(int reference) throws ErrorAccesException {
        String sql = "SELECT * FROM publishingHouse WHERE reference = ?";
        try {
            PreparedStatement statement = dataBaseAccess.prepareStatement(sql);
            statement.setInt(1, reference);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return new PublishingHouseAdminModel(resultSet.getInt("reference"),
                        resultSet.getString("publishingName"));
            } else {
                throw new ErrorAccesException("Maison d'édition introuvable : " + reference);
            }
        } catch (SQLException e) {
            throw new ErrorAccesException(e.getMessage());
        }
    }
    private AuthorAdminModel getAuthorById(int reference) throws ErrorAccesException {
        String sql = "SELECT * FROM author WHERE reference = ?";
        try {
            PreparedStatement statement = dataBaseAccess.prepareStatement(sql);
            statement.setInt(1, reference);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                LocalDate deathDate = null;
                if (resultSet.getDate("deathDate") != null) {
                    deathDate = resultSet.getDate("deathDate").toLocalDate();
                }
                return new AuthorAdminModel(resultSet.getInt("reference"),
                        resultSet.getString("firstname"),
                        resultSet.getString("lastname"),
                        resultSet.getDate("dateOfBirth").toLocalDate(),
                        resultSet.getString("nationality"),
                        deathDate);
            } else {
                throw new ErrorAccesException("L'auteur introuvable : " + reference);
            }
        } catch (SQLException e) {
            throw new ErrorAccesException(e.getMessage());
        }
    }

    @Override
    public void addBook(BookAdminModel book) throws ErrorAccesException {
        String sql = "INSERT INTO book(isbn,publicationDate,title,nbCopies,category,isAvailable,illustrated,publicationHouse,authorWriting) VALUES (?,?,?,?,?,?,?,?,?);";
        try {
            dataBaseAccess = SingletonConnexion.getInstance();
            PreparedStatement statement = dataBaseAccess.prepareStatement(sql);
            statement.setString(1, book.getIsbn());
            statement.setDate(2, java.sql.Date.valueOf(book.getPublicationDate()));
            statement.setString(3, book.getTitle());
            statement.setInt(4, book.getNbCopies());
            statement.setString(5, book.getCategory());
            statement.setBoolean(6, book.getIsAvailable());
            statement.setBoolean(7, book.getIllustrated());
            statement.setInt(8, book.getPublicationHouse().getReference());
            statement.setInt(9, book.getAuthorWriting().getReference());
            statement.executeUpdate();
        } catch (SQLException exception) {
            throw new ErrorAccesException("erreur d'ajout dans la base de donnée");
        }
    }

    @Override
    public void alterBook(BookAdminModel book) throws ErrorAccesException {
        String sql = "UPDATE book SET publicationDate = ?, title = ?, nbCopies = ?, category = ?, isAvailable = ?, illustrated = ?, publicationHouse = ?, authorWriting = ? WHERE isbn = ?";
        try {
            dataBaseAccess = SingletonConnexion.getInstance();
            PreparedStatement statement = dataBaseAccess.prepareStatement(sql);
            statement.setDate(1, java.sql.Date.valueOf(book.getPublicationDate()));
            statement.setString(2, book.getTitle());
            statement.setInt(3, book.getNbCopies());
            statement.setString(4, book.getCategory());
            statement.setBoolean(5, book.getIsAvailable());
            statement.setBoolean(6, book.getIllustrated());
            statement.setInt(7, book.getPublicationHouse().getReference());
            statement.setInt(8, book.getAuthorWriting().getReference());
            statement.setString(9,book.getIsbn());

            statement.executeUpdate();
        } catch (SQLException exception) {
            throw new ErrorAccesException("erreur de modification dans la base de donnée");
        }
    }

    @Override
    public void removeBook(String isbn) throws ErrorAccesException {
        String sql = "DELETE FROM book WHERE isbn = ?";
        try {
            dataBaseAccess = SingletonConnexion.getInstance();
            PreparedStatement statement = dataBaseAccess.prepareStatement(sql);
            statement.setString(1, isbn);
            statement.executeUpdate();
        } catch (SQLException exception) {
            throw new ErrorAccesException("erreur lors de la suppression dans la base de donnée");
        }
    }

    @Override
    public boolean checkIsbnValidity(String isbn) throws BookAlreadyExistsException {
        String sql = "SELECT * FROM book WHERE isbn = ?";
        try {
            dataBaseAccess = SingletonConnexion.getInstance();
            PreparedStatement statement = dataBaseAccess.prepareStatement(sql);
            statement.setString(1, isbn);
            ResultSet resultSet = statement.executeQuery();
            return resultSet.next();
        } catch (SQLException e) {
            throw new BookAlreadyExistsException("le livre existe déjà");
        }
    }
    public boolean ckeckTitleExist(String title) throws BookAlreadyExistsException {
        String sql = "SELECT * FROM book WHERE title = ?";
        try{
            dataBaseAccess = SingletonConnexion.getInstance();
            PreparedStatement statement = dataBaseAccess.prepareStatement(sql);
            statement.setString(1, title);
            ResultSet resultSet = statement.executeQuery();
            return resultSet.next();
        } catch (SQLException e) {
            throw new BookAlreadyExistsException("le livre existe déjà");
        }
    }

    @Override
    public ArrayList<PublishingHouseAdminModel> getAllPublishingHouses() throws ErrorAccesException {
        PublishingHouseAdminModel publishingHouse;
        ArrayList<PublishingHouseAdminModel> publishingHouses = new ArrayList<>();
        String sql = "SELECT * FROM publishingHouse";
        try {
            dataBaseAccess = SingletonConnexion.getInstance();
            PreparedStatement statement = dataBaseAccess.prepareStatement(sql);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                publishingHouse = new PublishingHouseAdminModel(resultSet.getInt("reference"),
                        resultSet.getString("publishingName"));
                publishingHouses.add(publishingHouse);
            }
        } catch (SQLException e) {
            throw new ErrorAccesException("Erreur maison d'édition dans la base de données");
        }
        return publishingHouses;
    }

    @Override
    public ArrayList<AuthorAdminModel> getAllAuthors() throws ErrorAccesException {
        AuthorAdminModel author;
        LocalDate deathDate;
        ArrayList<AuthorAdminModel> authors = new ArrayList<>();
        String sql = "SELECT * FROM author";
        try {
            dataBaseAccess = SingletonConnexion.getInstance();
            PreparedStatement statement = dataBaseAccess.prepareStatement(sql);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                author = new AuthorAdminModel(resultSet.getInt("reference"),
                        resultSet.getString("firstname"),
                        resultSet.getString("lastname"),
                        resultSet.getDate("dateOfBirth").toLocalDate(),
                        resultSet.getString("nationality"),
                        resultSet.getDate("deathDate") != null ? resultSet.getDate("deathDate").toLocalDate() : null);
                authors.add(author);
            }
        } catch (SQLException e) {
            throw new ErrorAccesException("Erreur d'Auteur dans la base de données");
        }
        return authors;
    }
}