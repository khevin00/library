package dataAccesPackage;

import exceptionPackage.ConnectionException;
import org.mindrot.jbcrypt.BCrypt;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AdminDataAcces implements AdminDAOInteface{
    @Override
    public Boolean adminPresent(String username, String password) throws ConnectionException {
        String requeteSQL = "select * from administrator where userName = ?";
        try{
            Connection connection = SingletonConnexion.getInstance();
            PreparedStatement preparedStatement = connection.prepareStatement(requeteSQL);
            preparedStatement.setString(1, username);

            ResultSet data = preparedStatement.executeQuery();
            if(data.next()){
                String storedHash = data.getString("password");
                return BCrypt.checkpw(password, storedHash);
            }
            return false;
        } catch (SQLException exception) {
            throw new ConnectionException("Erreur lors de la vérification de l'admin");
        }
    }
}
