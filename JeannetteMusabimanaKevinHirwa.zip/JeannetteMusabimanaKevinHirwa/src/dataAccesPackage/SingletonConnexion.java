package dataAccesPackage;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class SingletonConnexion {
    private static Connection connexion;
    public static Connection getInstance() throws SQLException{
        if(connexion == null){
            connexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/library", "root","kevin");
        }
        return connexion;
    }

}
