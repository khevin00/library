package dataAccesPackage;

import exceptionPackage.ErrorAccesException;
import modelPackage.BorrowDisplayModel;
import modelPackage.SearchAuthorModel;
import modelPackage.SearchDateModel;

import java.time.LocalDate;
import java.util.ArrayList;

public interface AuthorDAOInterface {
    ArrayList<String> getAllAuthorsNames() throws ErrorAccesException;
    ArrayList<SearchAuthorModel> getInformationsAboutAuthor(String fullName) throws ErrorAccesException;
    ArrayList<SearchDateModel> getInformationsWithDate(LocalDate firstDate, LocalDate secondDate) throws ErrorAccesException;
    ArrayList<BorrowDisplayModel> displayBorrowUserSearch(String user) throws ErrorAccesException;
    ArrayList<String> getAllUsers() throws ErrorAccesException;
}
