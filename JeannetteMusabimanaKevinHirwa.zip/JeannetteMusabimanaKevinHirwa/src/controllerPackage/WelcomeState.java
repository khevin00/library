package controllerPackage;

import viewPackage.WelcomePanel;

import javax.swing.*;

public class WelcomeState implements PanelState{
    @Override
    public JPanel createPanel(){
        return new WelcomePanel();
    }
}
