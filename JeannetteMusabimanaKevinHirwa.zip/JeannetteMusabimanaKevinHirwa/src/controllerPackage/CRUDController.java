package controllerPackage;

import businessPackage.CRUDManager;
import exceptionPackage.*;
import modelPackage.AuthorAdminModel;
import modelPackage.BookAdminModel;
import modelPackage.PublishingHouseAdminModel;

import java.sql.SQLException;
import java.util.ArrayList;

public class CRUDController {
    private CRUDManager crudManager;
    public CRUDController(){
        setCrudManager(new CRUDManager());
    }
    public void setCrudManager(CRUDManager crudManager){
        this.crudManager = crudManager;
    }

    public ArrayList<BookAdminModel> getAllBooks()throws ErrorAccesException{
        return crudManager.getAllBooks();
    }
    public ArrayList<PublishingHouseAdminModel> getAllPublishingHouses() throws ErrorAccesException{
        return crudManager.getAllPublishingHouses();
    }
    public ArrayList<AuthorAdminModel> getAllAuthors()throws ErrorAccesException{
        return crudManager.getAllAuthors();
    }
    public void addBook(BookAdminModel book) throws ErrorAccesException {
        crudManager.addBook(book);
    }
    public void alterBook(BookAdminModel book)throws ErrorAccesException{
        crudManager.alterBook(book);
    }
    public void removeBook(String isbn)throws ErrorAccesException{
        crudManager.removeBook(isbn);
    }
    public boolean checkIsbnValidity(String isbn) throws BookAlreadyExistsException, ErrorAccesException {
        return crudManager.checkIsbnValidity(isbn);
    }
    public boolean ckeckTitleExist(String title) throws BookAlreadyExistsException{
        return crudManager.ckeckTitleExist(title);
    }
}
