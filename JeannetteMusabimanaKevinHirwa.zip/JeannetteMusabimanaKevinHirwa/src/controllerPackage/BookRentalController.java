package controllerPackage;

import businessPackage.BookRentalManager;
import exceptionPackage.ErrorAccesException;
import modelPackage.BookBorrowModel;
import modelPackage.BookRentalModel;
import modelPackage.BorrowDisplayModel;

import java.util.ArrayList;

public class BookRentalController {
    private BookRentalManager bookRentalManager;

    public BookRentalController() {
        setBookRentalManager(new BookRentalManager());
    }
    public void setBookRentalManager(BookRentalManager bookRentalManager) {
        this.bookRentalManager = bookRentalManager;
    }
    public ArrayList<BookRentalModel> getAllBooks() throws ErrorAccesException {
        return bookRentalManager.getAllBooks();
    }
    public boolean rentalBook(String title) throws ErrorAccesException{
        return bookRentalManager.rentalBook(title);
    }
    public void addBookInBorrow(String title, String user) throws ErrorAccesException {
        bookRentalManager.addBookInBorrow(title, user);
    }
    public ArrayList<BookBorrowModel> displayBorrowBook(String user) throws ErrorAccesException{
        return bookRentalManager.displayBorrowBook(user);
    }
    public boolean bookAlreadyRented(String user, String title) throws ErrorAccesException{
        return bookRentalManager.bookAlreadyRented(user, title);
    }
    public void returnBook(String isbn) throws ErrorAccesException{
         bookRentalManager.returnBook(isbn);
    }
    public void updateCurrentlyRented(String user, String isbn) throws ErrorAccesException{
        bookRentalManager.updateCurrentlyRented(user, isbn);
    }
    public String getISBN(String title) throws ErrorAccesException{
        return bookRentalManager.getISBN(title);
    }

}
