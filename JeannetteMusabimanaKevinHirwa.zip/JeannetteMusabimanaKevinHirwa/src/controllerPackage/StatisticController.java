package controllerPackage;

import businessPackage.StatisticManager;
import exceptionPackage.BookCountException;
import exceptionPackage.BookNotFoundException;
import exceptionPackage.DivisionException;
import modelPackage.StatisticCategoryTableModel;

import java.util.ArrayList;

public class StatisticController {
    private StatisticManager statisticManager;

    public StatisticController() {
        setStatistiqueManager(new StatisticManager());
    }
    public void setStatistiqueManager(StatisticManager statisticManager) {
        this.statisticManager = statisticManager;
    }
    public ArrayList<StatisticCategoryTableModel> calculateCategoryPercentageForUser(String user) throws BookCountException, DivisionException {
        return statisticManager.calculateCategoryPercentageForUser(user);
    }
}
