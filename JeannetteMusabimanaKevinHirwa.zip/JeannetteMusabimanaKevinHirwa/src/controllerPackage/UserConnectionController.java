package controllerPackage;

import businessPackage.UserConnectionManager;
import exceptionPackage.ConnectionException;

public class UserConnectionController {
    private UserConnectionManager userConnectionManager;
    public UserConnectionController(){
        setUserConnectionManager(new UserConnectionManager());
    }
    public void setUserConnectionManager(UserConnectionManager connectionManager){
        this.userConnectionManager = connectionManager;
    }
    public boolean userConnection(String username, String password) throws ConnectionException{
        return this.userConnectionManager.connectionUser(username, password);
    }
}
