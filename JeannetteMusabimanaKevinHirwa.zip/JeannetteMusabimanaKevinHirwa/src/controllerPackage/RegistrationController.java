package controllerPackage;

import businessPackage.RegistrationManager;
import dataAccesPackage.ConnectionDataAcces;
import exceptionPackage.ConnectionException;
import exceptionPackage.ExistException;

import java.sql.SQLException;
import java.time.LocalDate;

public class RegistrationController {
    private RegistrationManager registrationManager;
    public RegistrationController(){
        setRegistrationManager(new RegistrationManager());
    }

    public void setRegistrationManager(RegistrationManager registrationManager) {
        this.registrationManager = registrationManager;
    }
    public boolean registerUser(String lastname, String firstname, LocalDate birthdate, String username, String password) throws SQLException, ExistException, ConnectionException {
        return registrationManager.registerUser(lastname, firstname,birthdate, username, password);
    }
}
