package controllerPackage;

import businessPackage.AdminAuthManager;
import exceptionPackage.ConnectionException;

public class AdminAuthController {
    private AdminAuthManager adminAuthManager;
    public AdminAuthController(){
        setAdminAuthManager(new AdminAuthManager());
    }
    public void setAdminAuthManager(AdminAuthManager adminAuthManager){
        this.adminAuthManager = adminAuthManager;
    }
    public boolean connectionAdmin(String username, String password) throws ConnectionException {
        return adminAuthManager.connectionAdmin(username, password);
    }
}
