package controllerPackage;

import javax.swing.*;
public class PanelContext {
    // elle va maintenir une référence à l'état actuel
    private PanelState currentState;
    public void setCurrentState(PanelState newState){
        this.currentState = newState;
    }
    public JPanel getPanel(){
            return currentState.createPanel();
    }

}
