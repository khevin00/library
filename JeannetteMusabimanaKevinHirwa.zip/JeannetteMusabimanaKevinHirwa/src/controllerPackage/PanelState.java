package controllerPackage;

import javax.swing.*;

public interface PanelState {
    JPanel createPanel();
}
