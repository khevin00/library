package controllerPackage;

public interface LoginSuccessListener {
    void onLoginSuccess();
}
