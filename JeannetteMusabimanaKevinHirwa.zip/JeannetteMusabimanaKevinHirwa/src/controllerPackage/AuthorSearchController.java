package controllerPackage;

import businessPackage.AuthorSearchManager;
import exceptionPackage.ErrorAccesException;
import modelPackage.BorrowDisplayModel;
import modelPackage.SearchAuthorModel;
import modelPackage.SearchDateModel;

import java.time.LocalDate;
import java.util.ArrayList;

public class AuthorSearchController {
    private AuthorSearchManager authorSearchManager;

    public AuthorSearchController(){
        setAuthorSearchManager(new AuthorSearchManager());
    }
    public void setAuthorSearchManager(AuthorSearchManager authorSearchManager) {
        this.authorSearchManager = authorSearchManager;
    }
    public ArrayList<String> getAllAuthorsNames() throws ErrorAccesException {
        return authorSearchManager.getAllAuthorsNames();
    }
    public ArrayList<SearchAuthorModel> getInformationsAboutAuthor(String fullName) throws ErrorAccesException{
        return authorSearchManager.getInformationsAboutAuthor(fullName);
    }
    public ArrayList<SearchDateModel> getInformationsWithDate(LocalDate firstSelecteddate, LocalDate secondSelectedDate) throws ErrorAccesException {
        return authorSearchManager.getInformationsWithDate(firstSelecteddate, secondSelectedDate);
    }
    public ArrayList<BorrowDisplayModel> displayBorrowUserSearch(String user) throws ErrorAccesException{
        return authorSearchManager.displayBorrowUserSearch(user);
    }
    public ArrayList<String> getAllUsers() throws ErrorAccesException {
        return authorSearchManager.getAllUsers();
    }
}

