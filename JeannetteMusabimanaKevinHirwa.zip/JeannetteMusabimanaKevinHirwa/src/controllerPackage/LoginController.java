package controllerPackage;

import businessPackage.UserManager;
import modelPackage.UserModel;

import java.util.ArrayList;
import java.util.List;

public class LoginController {
    private List<LoginSuccessListener> listeners = new ArrayList<>();

    public void addLoginListener(LoginSuccessListener listener) {
        listeners.add(listener);
    }

    public void removeLoginListener(LoginSuccessListener listener) {
        listeners.remove(listener);
    }

    public void notifyLoginSuccess() {
        for (LoginSuccessListener listener : listeners) {
            listener.onLoginSuccess();
        }
    }

    public void attemptLogin(String username, String password) {
        UserManager.getInstance().setUser(new UserModel(username, password));

    }
}
