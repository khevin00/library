package controllerPackage;

import viewPackage.AdminPanel;

import javax.swing.*;

public class AdminState implements PanelState {
    @Override
    public JPanel createPanel() {
        return new AdminPanel();
    }
}
