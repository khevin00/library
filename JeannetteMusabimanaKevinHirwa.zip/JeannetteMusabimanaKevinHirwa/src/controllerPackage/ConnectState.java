package controllerPackage;

import viewPackage.ConnectJPanel;
import viewPackage.MainFrame;

import javax.swing.*;

public class ConnectState implements PanelState {
    @Override

    public JPanel createPanel() {
        return new ConnectJPanel();
    }
}
