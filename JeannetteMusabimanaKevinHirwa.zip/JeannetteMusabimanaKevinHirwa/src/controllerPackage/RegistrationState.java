package controllerPackage;

import viewPackage.RegistrationPanel;

import javax.swing.*;

public class RegistrationState implements PanelState{
    @Override
    public JPanel createPanel() {
        return new RegistrationPanel();


    }
}
