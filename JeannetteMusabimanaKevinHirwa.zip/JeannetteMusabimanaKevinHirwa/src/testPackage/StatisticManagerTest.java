package testPackage;

import businessPackage.StatisticManager;
import exceptionPackage.BookCountException;
import exceptionPackage.BookNotFoundException;
import exceptionPackage.DivisionException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class StatisticManagerTest {
    private StatisticManager statisticManager;

    @BeforeEach
    public void setUp(){
        statisticManager = new StatisticManager();
    }
    @Test
    public void testCalculateCategoryPercentageForUser_BookCountException() throws BookCountException, BookNotFoundException, DivisionException {
        statisticManager.calculateCategoryPercentageForUser("user2");
    }
    @Test
    public void testCalculateCategoryPercentageForUser_BookNotFoundException() throws BookCountException, BookNotFoundException, DivisionException {
        statisticManager.calculateCategoryPercentageForUser("user3");
    }

    @Test
    public void testDivision(){
        assertThrows(DivisionException.class, () -> {
            statisticManager.division(12.0,0.0);
        });
    }
}