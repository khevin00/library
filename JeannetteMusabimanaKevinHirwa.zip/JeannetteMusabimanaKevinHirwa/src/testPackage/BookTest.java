package testPackage;

import exceptionPackage.*;
import modelPackage.BookAdminModel;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class BookTest {
    private BookAdminModel book;

    @BeforeEach
    public void setUp(){ book = new BookAdminModel();}

    @Test
    public void isbn(){
        book.setIsbn("9782070345436");
        assertEquals("9782070345436",book.getIsbn());
    }
    @Test
    public void title(){
        book.setTitle("La peste");
        assertEquals("La peste",book.getTitle());
    }
    @Test
    public void nbCopies(){
        book.setNbCopies(10);
        assertEquals(10,book.getNbCopies());
    }
    @Test
    public  void SetIsbnNull(){
        assertThrows(BookAdminModelIsbnNullException.class,() -> book.setIsbn(null));
    }
    @Test
    public  void SetIsbnLength(){
        assertThrows(BookAdminModelIsbnLengthException.class,() -> book.setIsbn("La taille de isbn doit être de 13 chiffres"));
    }
    @Test
    public  void SetTitleNull(){
        assertThrows(BookAdminModelTitleNullException.class,() -> book.setTitle(null));
    }
    @Test
    public  void SetTitleLength(){
        assertThrows(BookAdminModelTitleLengthException.class,() -> book.setTitle("le titre ne peut pas dépasser 50 caractères"));
    }

    @Test
    public  void SetNbCopiesNull(){
        assertThrows(BookAdminModelNbCopiesNullException.class,() -> book.setNbCopies(null));
    }
    @Test
    public  void SetNbCopiesNegatif(){
        assertThrows(BookAdminModelNbCopiesNegatifException.class,() -> book.setTitle("Le nombre de copies ne peut pas être négatif"));
    }

}