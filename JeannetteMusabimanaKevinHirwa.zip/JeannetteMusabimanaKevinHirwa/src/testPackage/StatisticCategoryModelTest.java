package testPackage;

import modelPackage.StatisticCategoryModel;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;


public class StatisticCategoryModelTest {
    private StatisticCategoryModel statisticCategoryModel;

    @BeforeEach
    public void setUp(){
        statisticCategoryModel = new StatisticCategoryModel();
    }
    @Test
    public void username(){
        statisticCategoryModel.setUserName("John");
        assertEquals("John",statisticCategoryModel.getUserName());
    }
    @Test
    public void categoryName(){
        statisticCategoryModel.setCategoryName("Roman");
        assertEquals("Roman",statisticCategoryModel.getCategoryName());
    }
    @Test
    public  void booksNb(){
        statisticCategoryModel.getBooksNb();
        assertEquals(50,statisticCategoryModel.getBooksNb());
    }

}