package testPackage;

import modelPackage.AuthorAdminModel;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class AuthorAdminModelTest {
    private AuthorAdminModel authorAdminModel;

    @BeforeEach
    public void setUp(){
        authorAdminModel = new AuthorAdminModel();
    }
    @Test
    public  void reference(){
        authorAdminModel.setReference(4);
        assertEquals(4,authorAdminModel.getReference());
    }
    @Test
    public void firstname(){
        authorAdminModel.setFirstname("Albert");
        assertEquals("Albert",authorAdminModel.getFirstname());
    }
    @Test
    public void lastname(){
        authorAdminModel.setLastname("Camus");
        assertEquals("Camus",authorAdminModel.getLastname());
    }
    @Test
    public void nationality(){
        authorAdminModel.setNationality("Français");
        assertEquals("Français",authorAdminModel.getNationality());
    }
}
