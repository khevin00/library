package exceptionPackage;

public class BookAdminModelNbCopiesFormatException extends Exception{
    public BookAdminModelNbCopiesFormatException(String message){
        super(message);
    }
}