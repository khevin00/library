package exceptionPackage;

public class DivisionException extends Exception{
    public DivisionException(String message){
        super(message);
    }
}
