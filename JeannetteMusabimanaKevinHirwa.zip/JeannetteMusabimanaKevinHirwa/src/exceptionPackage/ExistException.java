package exceptionPackage;

public class ExistException extends Exception{
    public ExistException(String message) {
            super(message);
    }
}
