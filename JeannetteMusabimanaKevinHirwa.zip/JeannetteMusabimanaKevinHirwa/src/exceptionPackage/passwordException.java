package exceptionPackage;

public class passwordException extends Exception{
    public passwordException(String message){
    }
    public String getMessage() {
        return "le mot de passe est incorrect";
    }
}
