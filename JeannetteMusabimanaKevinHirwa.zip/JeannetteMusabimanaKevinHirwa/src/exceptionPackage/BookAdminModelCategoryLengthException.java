
package exceptionPackage;

public class BookAdminModelCategoryLengthException extends Exception{
    public BookAdminModelCategoryLengthException(String message){
        super(message);
    }
}