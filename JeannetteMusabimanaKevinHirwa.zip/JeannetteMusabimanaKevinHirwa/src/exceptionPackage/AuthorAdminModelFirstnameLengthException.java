package exceptionPackage;

public class AuthorAdminModelFirstnameLengthException extends Exception{
    public AuthorAdminModelFirstnameLengthException(String message){
        super(message);
    }
}