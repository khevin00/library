package exceptionPackage;

public class BookAdminModelPublishingHouseNullException extends Exception{
    public BookAdminModelPublishingHouseNullException(String message){
        super(message);
    }
}