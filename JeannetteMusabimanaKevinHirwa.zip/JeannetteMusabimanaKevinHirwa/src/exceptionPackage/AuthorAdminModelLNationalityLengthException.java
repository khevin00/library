package exceptionPackage;

public class AuthorAdminModelLNationalityLengthException extends Exception{
    public AuthorAdminModelLNationalityLengthException(String message){
        super(message);
    }
}
