
package exceptionPackage;

public class BookAdminModelNbCopiesNullException extends Exception{
    public BookAdminModelNbCopiesNullException(String message){
        super(message);
    }
}