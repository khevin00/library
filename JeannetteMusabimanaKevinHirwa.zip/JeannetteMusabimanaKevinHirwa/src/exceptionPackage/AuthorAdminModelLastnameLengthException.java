package exceptionPackage;

public class AuthorAdminModelLastnameLengthException extends Exception{
    public AuthorAdminModelLastnameLengthException(String message){
        super(message);
    }
}