package exceptionPackage;

public class DateException extends Exception{
    private String wrongDate;
    public DateException(String wrongDate){
        setWrongDate(wrongDate);
    }
    public void setWrongDate(String wrongDate){
        this.wrongDate = wrongDate;
    }
    public String getMessage(){
        return wrongDate +" est dans un format incorrect ! veillez utilisez le format suivant : dd/MM/YYYY";
    }

}
