package exceptionPackage;

public class BookAdminModelTitleLengthException extends Exception{
    public BookAdminModelTitleLengthException(String message){
        super(message);
    }
}