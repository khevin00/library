package exceptionPackage;

public class usernameException extends Exception{
    public usernameException(String message){
    }
    public String getMessage() {
        return "le nom d'utilisateur est incorrect";
    }
}
