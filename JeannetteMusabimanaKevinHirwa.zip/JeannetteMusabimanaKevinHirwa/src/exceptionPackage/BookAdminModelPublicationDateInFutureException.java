package exceptionPackage;

public class BookAdminModelPublicationDateInFutureException extends Exception{
    public  BookAdminModelPublicationDateInFutureException(String message){
        super(message);
    }
}