package exceptionPackage;

public class AuthorAdminModelLastnameNullException extends Exception{
    public AuthorAdminModelLastnameNullException(String message){
        super(message);
    }
}