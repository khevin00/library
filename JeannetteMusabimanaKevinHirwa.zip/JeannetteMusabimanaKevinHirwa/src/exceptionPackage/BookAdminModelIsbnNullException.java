package exceptionPackage;

public class BookAdminModelIsbnNullException extends Exception{
    public BookAdminModelIsbnNullException(String message){
        super(message);
    }
}