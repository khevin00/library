package exceptionPackage;

public class ErrorAccesException extends Exception{
    public ErrorAccesException(String message){
        super(message);
    }
}
