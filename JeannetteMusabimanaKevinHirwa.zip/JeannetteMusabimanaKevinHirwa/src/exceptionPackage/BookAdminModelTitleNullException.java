
package exceptionPackage;

public class BookAdminModelTitleNullException extends Exception{
    public BookAdminModelTitleNullException(String message){
        super(message);
    }
}