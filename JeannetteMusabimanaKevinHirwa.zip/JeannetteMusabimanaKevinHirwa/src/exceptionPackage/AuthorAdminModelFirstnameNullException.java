package exceptionPackage;

public class AuthorAdminModelFirstnameNullException extends Exception{
    public AuthorAdminModelFirstnameNullException(String message){
        super(message);
    }
}