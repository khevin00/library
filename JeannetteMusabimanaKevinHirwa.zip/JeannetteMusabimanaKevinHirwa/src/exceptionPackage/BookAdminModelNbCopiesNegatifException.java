package exceptionPackage;

public class BookAdminModelNbCopiesNegatifException extends Exception{
    public BookAdminModelNbCopiesNegatifException(String message){
        super(message);
    }
}