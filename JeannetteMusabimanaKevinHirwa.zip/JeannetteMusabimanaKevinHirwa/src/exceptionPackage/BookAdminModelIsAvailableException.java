package exceptionPackage;

public class BookAdminModelIsAvailableException  extends Exception {
    public BookAdminModelIsAvailableException(String message) {
        super(message);
    }
}
