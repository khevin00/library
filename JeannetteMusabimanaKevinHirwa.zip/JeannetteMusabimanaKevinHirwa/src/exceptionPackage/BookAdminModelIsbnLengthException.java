package exceptionPackage;

public class BookAdminModelIsbnLengthException extends Exception{
    public BookAdminModelIsbnLengthException(String message){
        super(message);
    }
}