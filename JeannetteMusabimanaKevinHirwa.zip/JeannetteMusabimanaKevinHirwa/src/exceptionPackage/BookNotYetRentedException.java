package exceptionPackage;

public class BookNotYetRentedException extends Exception {
    public BookNotYetRentedException(String message){
        super(message);
    }
}
