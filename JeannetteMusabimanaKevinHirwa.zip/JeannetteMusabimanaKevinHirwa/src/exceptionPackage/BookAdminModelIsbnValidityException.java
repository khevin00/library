package exceptionPackage;

public class BookAdminModelIsbnValidityException extends Exception{
    public BookAdminModelIsbnValidityException(String message){
        super(message);
    }
}