package exceptionPackage;

public class BookCountException extends Exception {
    public BookCountException(String message) {
            super(message);
    }
}
