package exceptionPackage;

public class FillAllException extends Exception{
    public FillAllException(String message){
        super(message);
    }
}
