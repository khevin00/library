package businessPackage;

import dataAccesPackage.CRUDDAOInterface;
import dataAccesPackage.CRUDDataAcces;
import exceptionPackage.*;
import  modelPackage.BookAdminModel;
import  modelPackage.AuthorAdminModel;
import  modelPackage.PublishingHouseAdminModel;
import  java.util.ArrayList;

public class CRUDManager {
    private CRUDDAOInterface cruddaoInterface;
    public CRUDManager(){
        setCruddaoInterface(new CRUDDataAcces());
    }
    public void setCruddaoInterface(CRUDDAOInterface cruddaoInterface){
        this.cruddaoInterface = cruddaoInterface;
    }

    public ArrayList<BookAdminModel> getAllBooks()throws ErrorAccesException{
        return cruddaoInterface.getAllBooks();
    }

    public ArrayList<PublishingHouseAdminModel> getAllPublishingHouses() throws ErrorAccesException{
        return cruddaoInterface.getAllPublishingHouses();
    }
    public ArrayList<AuthorAdminModel> getAllAuthors()throws ErrorAccesException{
        return cruddaoInterface.getAllAuthors();
    }
    public void addBook(BookAdminModel book) throws ErrorAccesException{
        cruddaoInterface.addBook(book);
    }
    public void alterBook(BookAdminModel book)throws ErrorAccesException{
        cruddaoInterface.alterBook(book);
    }
    public void removeBook(String isbn)throws ErrorAccesException{
        cruddaoInterface.removeBook(isbn);
    }
    public boolean checkIsbnValidity(String isbn) throws BookAlreadyExistsException, ErrorAccesException {
        return cruddaoInterface.checkIsbnValidity(isbn);
    }

    public boolean ckeckTitleExist(String title) throws BookAlreadyExistsException{
        return cruddaoInterface.ckeckTitleExist(title);
    }
}