package businessPackage;

import dataAccesPackage.StatisticDAOInterface;
import dataAccesPackage.StatisticDataAcces;
import exceptionPackage.BookCountException;
import exceptionPackage.DivisionException;
import modelPackage.StatisticCategoryModel;
import modelPackage.StatisticCategoryTableModel;

import java.util.ArrayList;

public class StatisticManager {
    StatisticDAOInterface statisticDAO;

    public StatisticManager() {
        setStatisticDAO(new StatisticDataAcces());
    }
    public void setStatisticDAO(StatisticDAOInterface statisticDAO) {
        this.statisticDAO = statisticDAO;
    }

    public ArrayList<StatisticCategoryTableModel> calculateCategoryPercentageForUser(String user) throws BookCountException, DivisionException {
        ArrayList<StatisticCategoryModel> borrowCounts = statisticDAO.getBorrowCountsByCategoryForUser(user);
        int totalBorrows = statisticDAO.getBookCount(user);
        ArrayList<StatisticCategoryTableModel> percentages = new ArrayList<>();

        for (StatisticCategoryModel model : borrowCounts) {
            double percentage = division(model.getBooksNb(), totalBorrows);
            percentage = Math.round(percentage * 100.0) / 100.0;
            StatisticCategoryTableModel statistic = new StatisticCategoryTableModel(model.getCategoryName(),percentage);
            percentages.add(statistic);
        }
        return percentages;
    }
    public Double division(double nbBooks, double totalBorrows) throws DivisionException {
        if(totalBorrows == 0){
            throw new DivisionException("le diviseur ne doit être 0");
        }
        return nbBooks/ totalBorrows * 100;
    }


}
