package businessPackage;

import dataAccesPackage.BookDAOInterface;
import dataAccesPackage.BookDataAcces;
import exceptionPackage.InputException;
import modelPackage.BookModel;

import java.util.ArrayList;

public class SearchBookManager {
    private BookDAOInterface bookDAO;
    public SearchBookManager() {
        setSearchBookData(new BookDataAcces());
    }
    public void setSearchBookData(BookDataAcces bookDataAcces){
        this.bookDAO = bookDataAcces;
    }
    public ArrayList<BookModel> searchBooks(String bookTitle, String authorName, Integer publishingYear) throws InputException {
        return bookDAO.searchBooks(bookTitle, authorName, publishingYear);
    }
}
