package businessPackage;

import dataAccesPackage.AuthorDAOInterface;
import dataAccesPackage.AuthorDataAcces;
import exceptionPackage.ErrorAccesException;
import modelPackage.BorrowDisplayModel;
import modelPackage.SearchAuthorModel;
import modelPackage.SearchDateModel;

import java.time.LocalDate;
import java.util.ArrayList;

public class AuthorSearchManager {
    private AuthorDAOInterface authorDAO;

    public AuthorSearchManager(){
        setAuthorDAO(new AuthorDataAcces());
    }
    public void setAuthorDAO(AuthorDAOInterface authorDAO) {
        this.authorDAO = authorDAO;
    }
    public ArrayList<String> getAllAuthorsNames() throws ErrorAccesException{
        return authorDAO.getAllAuthorsNames();
    }
    public ArrayList<SearchAuthorModel> getInformationsAboutAuthor(String fullName) throws ErrorAccesException{
        return authorDAO.getInformationsAboutAuthor(fullName);
    }
    public ArrayList<SearchDateModel> getInformationsWithDate(LocalDate firstSelecteddate, LocalDate secondSelectedDate) throws ErrorAccesException{
        return authorDAO.getInformationsWithDate(firstSelecteddate, secondSelectedDate);
    }
    public ArrayList<BorrowDisplayModel> displayBorrowUserSearch(String user) throws ErrorAccesException{
        return authorDAO.displayBorrowUserSearch(user);
    }
    public ArrayList<String> getAllUsers() throws ErrorAccesException {
        return authorDAO.getAllUsers();
    }
}
