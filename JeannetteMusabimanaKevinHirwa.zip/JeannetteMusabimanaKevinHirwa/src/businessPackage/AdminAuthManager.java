package businessPackage;

import dataAccesPackage.AdminDAOInteface;
import dataAccesPackage.AdminDataAcces;
import exceptionPackage.ConnectionException;

public class AdminAuthManager {
    private AdminDAOInteface admindao;
    public AdminAuthManager(){
        setAdmindao(new AdminDataAcces());
    }
    public void setAdmindao(AdminDAOInteface adminDAOInteface){
        this.admindao = adminDAOInteface;
    }
    public boolean connectionAdmin(String username, String password) throws ConnectionException{
        return admindao.adminPresent(username, password);
    }
}
