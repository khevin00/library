package businessPackage;

import dataAccesPackage.DisplayBookDAOInteface;
import dataAccesPackage.DisplayBookDataAcces;
import exceptionPackage.ErrorAccesException;
import modelPackage.BookModel;

import java.util.ArrayList;
import java.util.List;
public class BookManager {
    private DisplayBookDAOInteface bookDAO;

    public BookManager() {
        setBookDAO(new DisplayBookDataAcces());
    }

    public void setBookDAO(DisplayBookDAOInteface bookDAO) {
        this.bookDAO = bookDAO;
    }

    public List<String> retrieveAllBookTitles() throws ErrorAccesException {
        return bookDAO.getAllBooks();
    }

    public BookModel getBookByTitle(String title) throws ErrorAccesException {
        return bookDAO.getBookByTitle(title);
    }

    public ArrayList<String> getAllAuthorsNames() throws ErrorAccesException {
        return bookDAO.getAllAuthorsNames();
    }
    public ArrayList<String> getAllPublishingNames() throws ErrorAccesException{
        return bookDAO.getAllPublishingNames();
    }
}