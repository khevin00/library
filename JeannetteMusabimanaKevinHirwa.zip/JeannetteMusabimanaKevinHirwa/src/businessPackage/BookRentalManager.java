package businessPackage;

import dataAccesPackage.BookRentalDAOInterface;
import dataAccesPackage.BookRentalDataAcces;
import exceptionPackage.ErrorAccesException;
import modelPackage.BookBorrowModel;
import modelPackage.BookRentalModel;
import modelPackage.BorrowDisplayModel;

import java.util.ArrayList;

public class BookRentalManager {
    private BookRentalDAOInterface bookRentalDAO;

    public BookRentalManager() {
        setBookRentalDAO(new BookRentalDataAcces());
    }
    public void setBookRentalDAO(BookRentalDAOInterface bookRentalDAO) {
        this.bookRentalDAO = bookRentalDAO;
    }
    public ArrayList<BookRentalModel> getAllBooks() throws ErrorAccesException {
        return bookRentalDAO.getAllBooks();
    }
    public boolean rentalBook(String title) throws ErrorAccesException{
        return bookRentalDAO.rentalBook(title);
    }
    public void addBookInBorrow(String title, String user) throws ErrorAccesException{
        bookRentalDAO.addBookInBorrow(title, user);
    }
    public ArrayList<BookBorrowModel> displayBorrowBook(String user) throws ErrorAccesException{
        return bookRentalDAO.displayBorrowBook(user);
    }
    public boolean bookAlreadyRented(String user, String title) throws ErrorAccesException{
        return bookRentalDAO.bookAlreadyRented(user, title);
    }
    public void returnBook(String isbn) throws ErrorAccesException{
         bookRentalDAO.returnBook(isbn);
    }
    public void updateCurrentlyRented(String user, String isbn) throws ErrorAccesException{
        bookRentalDAO.updateCurrentlyRented(user, isbn);
    }
    public String getISBN(String title) throws ErrorAccesException{
        return bookRentalDAO.getISBN(title);
    }

}
