package businessPackage;

import dataAccesPackage.ConnectionDAOInterface;
import dataAccesPackage.ConnectionDataAcces;
import exceptionPackage.ConnectionException;


public class UserConnectionManager {
    private ConnectionDAOInterface connectionDAO;

    public UserConnectionManager(){
        setConnectionDataAcces(new ConnectionDataAcces());
    }

    public void setConnectionDataAcces(ConnectionDataAcces connectionDataAcces) {
        this.connectionDAO = connectionDataAcces;
    }
    public boolean connectionUser(String username, String password) throws ConnectionException{
        return connectionDAO.userPresent(username, password);
    }
}
