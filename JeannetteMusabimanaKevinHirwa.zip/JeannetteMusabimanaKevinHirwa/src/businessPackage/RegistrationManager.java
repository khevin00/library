package businessPackage;

import dataAccesPackage.ConnectionDAOInterface;
import dataAccesPackage.ConnectionDataAcces;
import exceptionPackage.ConnectionException;
import exceptionPackage.ExistException;

import java.sql.SQLException;
import java.time.LocalDate;

public class RegistrationManager {
    private ConnectionDAOInterface connectionDAO;
    public RegistrationManager(){
        setConnectionDAO(new ConnectionDataAcces());
    }
    public void setConnectionDAO(ConnectionDAOInterface connectionDAO){
        this.connectionDAO = connectionDAO;
    }
    public boolean registerUser(String lastname, String firstname, LocalDate birthdate, String username, String password) throws SQLException, ExistException, ConnectionException {
        return connectionDAO.registerUser(lastname, firstname,birthdate, username, password);
    }
}
