package viewPackage;

import modelPackage.BookAdminModel;
import modelPackage.AuthorAdminModel;
import modelPackage.PublishingHouseAdminModel;
import javax.swing.table.AbstractTableModel;
import java.util.List;
import java.time.LocalDate;

public class AllBooksModel extends AbstractTableModel {
    private final String[] columnNames = {
            "ISBN", "Date de publication", "Titre", "Nombre de copies", "Catégorie",
            "Disponible", "Illustré", "Maison d'édition", "Auteur"
    };
    private List<BookAdminModel> books;
    private List<PublishingHouseAdminModel> publishingHouses;
    private List<AuthorAdminModel> authors;

    public AllBooksModel(List<BookAdminModel> books, List<PublishingHouseAdminModel> publishingHouses, List<AuthorAdminModel> authors) {
        this.books = books;
        this.publishingHouses = publishingHouses;
        this.authors = authors;
    }

    @Override
    public int getRowCount() {
        return books.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        BookAdminModel book = books.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return book.getIsbn();
            case 1:
                return book.getPublicationDate();
            case 2:
                return book.getTitle();
            case 3:
                return book.getNbCopies();
            case 4:
                return book.getCategory();
            case 5:
                return book.getIsAvailable();
            case 6:
                return book.getIllustrated();
            case 7:
                return book.getPublicationHouse().getPublishingName();
            case 8:
                return book.getAuthorWriting().toString();
            default:
                return null;
        }
    }
    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return true; // Toutes les cellules sont éditables
    }

    @Override
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        BookAdminModel book = books.get(rowIndex);
        switch (columnIndex) {
            case 0:
                book.setIsbn((String) aValue);
                break;
            case 1:
                book.setPublicationDate((LocalDate) aValue);
                break;
            case 2:
                book.setTitle((String) aValue);
                break;
            case 3:
                book.setNbCopies((Integer) aValue);
                break;
            case 4:
                book.setCategory((String) aValue);
                break;
            case 5:
                book.setIsAvailable((Boolean) aValue);
                break;
            case 6:
                book.setIllustrated((Boolean) aValue);
                break;
            case 7:
                for (PublishingHouseAdminModel publicationHouse : publishingHouses) {
                    if ((publicationHouse.getPublishingName() + " (" + publicationHouse.getReference() + ")").equals(aValue)) {
                        book.setPublicationHouse(publicationHouse);
                        break;
                    }
                }
                break;
            case 8:
                for (AuthorAdminModel authorWriting : authors) {
                    if ((authorWriting.getFirstname() + " " + authorWriting.getLastname() + " (" + authorWriting.getReference() + ")").equals(aValue)) {
                        book.setAuthorWriting(authorWriting);
                        break;
                    }
                }
                break;
        }
        fireTableCellUpdated(rowIndex, columnIndex);
    }

    public BookAdminModel getBookAt(int rowIndex) {
        return books.get(rowIndex);
    }

    public void setBooks(List<BookAdminModel> updatedBooks) {
        this.books = updatedBooks; // Met à jour la liste des livres
        fireTableDataChanged();    // Notifie les écouteurs que les données ont changés
    }

}