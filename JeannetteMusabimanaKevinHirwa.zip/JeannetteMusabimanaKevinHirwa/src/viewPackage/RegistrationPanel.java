package viewPackage;

import controllerPackage.RegistrationController;
import exceptionPackage.FillAllException;
import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RegistrationPanel extends JPanel{
    private JLabel lastnameLabel, firstnameLabel, dateOfBirthLabel, userNameLabel,passwordLabel;
    private JTextField lastnameText, firstnameText, dateOfBirthText, userNameText;
    private JPasswordField passwordText;
    private JButton registerButton;
    private JSpinner birthDate;
    private RegistrationController registrationController;

    public RegistrationPanel(){
        this.setBounds(10,80,600,300);
        this.setLayout(new GridBagLayout());
        GridBagConstraints c1 = new GridBagConstraints();
        c1.insets = new Insets(5, 5, 5, 5);
        c1.fill = GridBagConstraints.HORIZONTAL;

        c1.gridx = 0; c1.gridy = 0;
        lastnameLabel = new JLabel("Nom*");
        this.add(lastnameLabel, c1);

        c1.gridx = 1; c1.gridy = 0;
        lastnameText = new JTextField(15);
        this.add(lastnameText, c1);

        c1.gridx = 0; c1.gridy = 1;
        firstnameLabel = new JLabel("Prénom*");
        this.add(firstnameLabel, c1);

        c1.gridx = 1; c1.gridy = 1;
        firstnameText = new JTextField(15);
        this.add(firstnameText, c1);

        c1.gridx = 0; c1.gridy = 2;
        dateOfBirthLabel = new JLabel("Date de Naissance*");
        this.add(dateOfBirthLabel, c1);

        Calendar calendar = Calendar.getInstance();
        Date initDate = calendar.getTime();
        calendar.add(Calendar.YEAR, -100);
        Date earliestDate = calendar.getTime();
        calendar.add(Calendar.YEAR, 200);
        Date latestDate = calendar.getTime();
        calendar.add(Calendar.YEAR, 200);
        SpinnerDateModel earliestDateModel = new SpinnerDateModel(initDate, earliestDate, latestDate, Calendar.YEAR);
        this.birthDate = new JSpinner(earliestDateModel);
        JSpinner.DateEditor editorStartDate = new JSpinner.DateEditor(birthDate, "dd-MM-yyyy");
        this.birthDate.setEditor(editorStartDate);

        c1.gridx = 1; c1.gridy = 2;
        this.add(birthDate, c1);

        c1.gridx = 0; c1.gridy = 3;
        userNameLabel = new JLabel("Nom d'utilisateur*");
        this.add(userNameLabel, c1);

        c1.gridx = 1; c1.gridy = 3;
        userNameText = new JTextField(15);
        this.add(userNameText, c1);

        c1.gridx = 0; c1.gridy = 4;
        passwordLabel = new JLabel("Mot de passe*");
        this.add(passwordLabel, c1);

        c1.gridx = 1; c1.gridy = 4;
        passwordText = new JPasswordField(15);
        this.add(passwordText, c1);

        c1.gridx = 0; c1.gridy = 5;
        // Le bouton s'étend sur deux colonnes
        c1.gridwidth = 2;
        // Ajuste l'emplacement du bouton
        c1.fill = GridBagConstraints.NONE;
        c1.anchor = GridBagConstraints.SOUTH;
        registerButton = new JButton("Soumettre");
        this.add(registerButton, c1);
        registerButton.addActionListener(new RegistrationListener());
    }
    public class RegistrationListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try{
                String lastname = lastnameText.getText();
                String firstname = lastnameText.getText();
                LocalDate date =  ((Date)birthDate.getValue()).toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                String username = userNameText.getText();
                char[] password = passwordText.getPassword();
                String passwordString = new String(password);
                if (lastname.isEmpty() || firstname.isEmpty() || date == null || username.isEmpty() || passwordString.isEmpty()) {
                    throw new FillAllException("veillez remplir tout les champs");
                }

                Period age = Period.between(date, LocalDate.now());
                if (age.getYears() < 16) {
                    throw new Exception("L'utilisateur doit avoir au moins 16 ans.");
                }
                registrationController = new RegistrationController();
                registrationController.registerUser(lastname,firstname,date,username,passwordString);
                JOptionPane.showMessageDialog(null, "l'inscription est valide", "Nouveau membre", JOptionPane.INFORMATION_MESSAGE);
            } catch (FillAllException exception) {
                JOptionPane.showMessageDialog(null, exception.getMessage(), "Erreur d'enregistrement", JOptionPane.ERROR_MESSAGE);
            } catch (Exception exception) {
                JOptionPane.showMessageDialog(null, exception.getMessage(), "Erreur Système", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
