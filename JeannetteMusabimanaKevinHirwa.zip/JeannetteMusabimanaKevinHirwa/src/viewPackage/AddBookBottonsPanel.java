package viewPackage;
import controllerPackage.CRUDController;
import exceptionPackage.*;
import modelPackage.BookAdminModel;
import modelPackage.AuthorAdminModel;
import modelPackage.PublishingHouseAdminModel;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.regex.Pattern;


public class AddBookBottonsPanel extends JPanel {
    private CRUDController controller;
    private BookFormPanel bookFormPanel;
    private String isbn, title,nbCopiesText, category;
    private LocalDate publicationDate;
    private Boolean illustrated = false;
    private Boolean isAvailable = false;
    private BookAdminModel book = new BookAdminModel();
    private AdminPanel username;
    private Integer nbCopies;
    private JSpinner publicationDateSpinner;
    private JRadioButton isAvailableYes, isAvailableNo, illustratedYes, illustratedNo;
    private JComboBox publishingHouseComboBox, authorWritingComboBox;
    private PublishingHouseAdminModel[] publishingHousesList;
    private AuthorAdminModel[] authorsList;
    private JButton submitButton;

    public AddBookBottonsPanel(BookFormPanel bookFormPanel, AdminPanel username) {
        this.setLayout(new GridLayout(1, 1));
        this.bookFormPanel = bookFormPanel;
        this.username = username;
        submitButton = new JButton("Ajouter");
        setController(new CRUDController());

        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                isbn = bookFormPanel.getIsbn().getText();
                publicationDateSpinner = bookFormPanel.getPublicationDateSpinner();
                JSpinner.DateEditor publicationDateEditor = bookFormPanel.getPublicationDateEditor();
                title = bookFormPanel.getTitle().getText();
                nbCopiesText = bookFormPanel.getNbCopies().getText();
                category = bookFormPanel.getCategory().getText();
                isAvailableYes = bookFormPanel.getIsAvailableYes();
                isAvailableNo = bookFormPanel.getIsAvailableNo();
                illustratedYes = bookFormPanel.getIllustratedYes();
                illustratedNo = bookFormPanel.getIllustratedNo();
                publishingHouseComboBox = bookFormPanel.getPublishingHouse();
                publishingHousesList = bookFormPanel.getPublishingHousesList();
                authorWritingComboBox = bookFormPanel.getAuthorWritingComboBox();
                authorsList = bookFormPanel.getAuthorsList();

                try {
                   if (isbn == null) {
                       throw new BookAdminModelIsbnNullException("Isbn ne peut pas être null");
                   }
                   if (isbn.length() != 13) {
                       throw new BookAdminModelIsbnLengthException("La taille de isbn doit être de 13 chiffres");
                   }
                   book.setIsbn(isbn);

                   if (controller.checkIsbnValidity(isbn) || controller.ckeckTitleExist(title)) {
                        throw new BookAlreadyExistsException("Ce livre existe déjà dans la base de données");
                   }
                   book.setIsbn(isbn);

                    if (Pattern.matches("^\\d{2}-\\d{2}-\\d{4}$", publicationDateEditor.getTextField().getText())) {
                        Date selectedDate = (Date) publicationDateSpinner.getValue();
                        LocalDate localDate = selectedDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

                        if (localDate.isAfter(LocalDate.now())) {
                            throw new BookAdminModelPublicationDateInFutureException("La date de publication ne peut pas dépasser la date d'aujourd'hui");
                        }
                        book.setPublicationDate(localDate);
                    } else {
                        throw new DateException(publicationDateEditor.getTextField().getText());
                    }


                    if (title == null) {
                        throw new BookAdminModelTitleNullException("Le titre du livre ne peut pas être null");
                    }
                    if(title.length() > 50){
                        throw new BookAdminModelTitleLengthException("le titre ne peut pas dépasser 50 caractères");
                    }
                    book.setTitle(title);


                    if (nbCopiesText.isEmpty()) {
                        throw new BookAdminModelNbCopiesNullException("Le nombre de copies ne peut pas être vide");
                    } else {
                            nbCopies = Integer.parseInt(nbCopiesText);
                            if (nbCopies < 0) {
                                throw new BookAdminModelNbCopiesNegatifException("Le nombre de copies ne peut pas être négatif");
                            }
                            book.setNbCopies(nbCopies);
                    }

                    if (category != null && category.length() > 30) {
                        throw new BookAdminModelCategoryLengthException("La taille de catégorie dépasse la taille allouée dans la base de données");
                    }
                    book.setCategory(category);


                    if(nbCopies == 0 && isAvailableYes.isSelected() || nbCopies > 0 && isAvailableNo.isSelected() ){
                        throw new BookAdminModelIsAvailableException("Veillez regler le problème de nombre de copies");
                    }
                    isAvailable = isAvailableYes.isSelected();
                    book.setIsAvailable(isAvailable);

                    illustrated = illustratedYes.isSelected();
                    book.setIllustrated(illustrated);

                    book.setAuthorWriting(authorsList[authorWritingComboBox.getSelectedIndex()]);

                    book.setPublicationHouse(publishingHousesList[publishingHouseComboBox.getSelectedIndex()]);

                    controller.addBook(book);
                    JOptionPane.showMessageDialog(null,"Livre ajouté avec succès !", "Succès", JOptionPane.INFORMATION_MESSAGE);

                } catch (Exception exception) {
                    JOptionPane.showMessageDialog(null, exception.getMessage(), exception.getClass().getSimpleName(), JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        this.add(submitButton);
    }
    public void setController(CRUDController controller) {
        this.controller = controller;
    }
}
