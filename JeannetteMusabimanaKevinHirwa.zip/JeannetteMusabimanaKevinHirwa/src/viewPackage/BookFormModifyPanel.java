package viewPackage;

import javax.swing.*;
import modelPackage.AuthorAdminModel;
import modelPackage.BookAdminModel;
import modelPackage.PublishingHouseAdminModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;

public class BookFormModifyPanel extends JPanel {
    private JComboBox<BookAdminModel> bookComboBox;
    private JTextField isbnField;
    private JSpinner publicationDateSpinner;
    private JTextField titleField;
    private JTextField nbCopiesField;
    private JTextField categoryField;
    private JRadioButton availableYes;
    private JRadioButton availableNo;
    private JRadioButton illustratedYes;
    private JRadioButton illustratedNo;
    private JComboBox<PublishingHouseAdminModel> publishingHouseComboBox;
    private JComboBox<AuthorAdminModel> authorComboBox;
    private List<PublishingHouseAdminModel> publishingHouses;
    private List<AuthorAdminModel> authors;
    private JButton refresh;

    public BookFormModifyPanel(List<BookAdminModel> books, List<PublishingHouseAdminModel> publishingHouses, List<AuthorAdminModel> authors) {

        this.publishingHouses = publishingHouses;
        this.authors = authors;

        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.NORTH;

        bookComboBox = new JComboBox<>(books.toArray(new BookAdminModel[0]));
        bookComboBox.addActionListener(e -> onBookSelected());

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        add(bookComboBox, gbc);

        // Labels
        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = 1;
        add(new JLabel("Isbn"), gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        add(new JLabel("Date de publication"), gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        add(new JLabel("Title"), gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        add(new JLabel("Nombre de copies"), gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        add(new JLabel("Catégorie"), gbc);

        gbc.gridx = 0;
        gbc.gridy = 6;
        add(new JLabel("Est-il disponibilité?"), gbc);

        gbc.gridx = 0;
        gbc.gridy = 7;
        add(new JLabel("Est-il illustré"), gbc);

        gbc.gridx = 0;
        gbc.gridy = 8;
        add(new JLabel("Maison d'édition"), gbc);

        gbc.gridx = 0;
        gbc.gridy = 9;
        add(new JLabel("Auteur"), gbc);

        // Fields
        isbnField = new JTextField();
        gbc.gridx = 1;
        gbc.gridy = 1;
        isbnField.setEditable(false);
        add(isbnField, gbc);

        publicationDateSpinner = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor dateEditor = new JSpinner.DateEditor(publicationDateSpinner, "dd-MM-yyyy");
        publicationDateSpinner.setEditor(dateEditor);
        gbc.gridx = 1;
        gbc.gridy = 2;
        add(publicationDateSpinner, gbc);

        titleField = new JTextField();
        gbc.gridx = 1;
        gbc.gridy = 3;
        add(titleField, gbc);

        nbCopiesField = new JTextField();
        gbc.gridx = 1;
        gbc.gridy = 4;
        add(nbCopiesField, gbc);

        categoryField = new JTextField();
        gbc.gridx = 1;
        gbc.gridy = 5;
        add(categoryField, gbc);

        availableYes = new JRadioButton("Oui");
        availableNo = new JRadioButton("Non");
        ButtonGroup availableGroup = new ButtonGroup();
        availableGroup.add(availableYes);
        availableGroup.add(availableNo);
        JPanel availablePanel = new JPanel();
        availablePanel.add(availableYes);
        availablePanel.add(availableNo);
        gbc.gridx = 1;
        gbc.gridy = 6;
        add(availablePanel, gbc);

        illustratedYes = new JRadioButton("Oui");
        illustratedNo = new JRadioButton("Non");
        ButtonGroup illustratedGroup = new ButtonGroup();
        illustratedGroup.add(illustratedYes);
        illustratedGroup.add(illustratedNo);
        JPanel illustratedPanel = new JPanel();
        illustratedPanel.add(illustratedYes);
        illustratedPanel.add(illustratedNo);
        gbc.gridx = 1;
        gbc.gridy = 7;
        add(illustratedPanel, gbc);

        publishingHouseComboBox = new JComboBox<>(publishingHouses.toArray(new PublishingHouseAdminModel[0]));
        gbc.gridx = 1;
        gbc.gridy = 8;
        add(publishingHouseComboBox, gbc);

        authorComboBox = new JComboBox<>(authors.toArray(new AuthorAdminModel[0]));
        gbc.gridx = 1;
        gbc.gridy = 9;
        add(authorComboBox, gbc);

        refresh = new JButton("Refresh");
        gbc.gridx = 1;
        gbc.gridy = 10;
        add(refresh, gbc);
        refresh.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                updateBookComboBox(books);
            }
        });
    }
    public BookFormModifyPanel() {

    }
    private void updateBookComboBox(List<BookAdminModel> books) {
        //bookComboBox.removeAllItems();
        bookComboBox = new JComboBox<>(books.toArray(new BookAdminModel[0]));
        bookComboBox.addActionListener(e -> onBookSelected());
    }


    private void onBookSelected() {
        BookAdminModel selectedBook = (BookAdminModel) bookComboBox.getSelectedItem();
        if (selectedBook != null) {
            isbnField.setText(selectedBook.getIsbn());
            publicationDateSpinner.setValue(java.sql.Date.valueOf(selectedBook.getPublicationDate()));
            titleField.setText(selectedBook.getTitle());
            nbCopiesField.setText(String.valueOf(selectedBook.getNbCopies()));
            categoryField.setText(selectedBook.getCategory());
            availableYes.setSelected(selectedBook.getIsAvailable());
            availableNo.setSelected(!selectedBook.getIsAvailable());
            illustratedYes.setSelected(selectedBook.getIllustrated());
            illustratedNo.setSelected(!selectedBook.getIllustrated());
            publishingHouseComboBox.setSelectedItem(selectedBook.getPublicationHouse());
            authorComboBox.setSelectedItem(selectedBook.getAuthorWriting());
        }
    }

    public BookAdminModel getBookFromFields() {
        String isbn = isbnField.getText();
        LocalDate publicationDate = ((java.util.Date) publicationDateSpinner.getValue()).toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        String title = titleField.getText();
        int nbCopies = Integer.parseInt(nbCopiesField.getText());
        String category = categoryField.getText();
        boolean isAvailable = availableYes.isSelected();
        boolean illustrated = illustratedYes.isSelected();
        PublishingHouseAdminModel publicationHouse = (PublishingHouseAdminModel) publishingHouseComboBox.getSelectedItem();
        AuthorAdminModel authorWriting = (AuthorAdminModel) authorComboBox.getSelectedItem();
        return new BookAdminModel(isbn, publicationDate, title, nbCopies, category, isAvailable, illustrated, publicationHouse, authorWriting);
    }
}