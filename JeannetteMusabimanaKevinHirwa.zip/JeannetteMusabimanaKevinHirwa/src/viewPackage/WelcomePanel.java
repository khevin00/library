package viewPackage;
import javax.swing.*;
import java.awt.*;

public class WelcomePanel extends JPanel {
    private JLabel titleLabel, contentlabel;
    public WelcomePanel() {
        super(new BorderLayout());
        setBackground(new Color(0xFFFFFF));

        AnimationPanel animationPanel = new AnimationPanel();
        animationPanel.setBackground(new Color(0xFFFFFF));
        animationPanel.setPreferredSize(new Dimension(115, 64));

        for (int i = 1; i <= 9; i++) {
            animationPanel.addAnimationFrame("resources/animation/book_opening_0" + i + ".png");
        }
        this.add(animationPanel, BorderLayout.NORTH);

        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        titleLabel = new JLabel("BIENVENUE A LA BIBLIOTHEQUE");
        titleLabel.setForeground(Color.orange);
        titleLabel.setFont(new Font("Arial", Font.ITALIC, 13));
        this.add(titleLabel, gbc);
    }
}
