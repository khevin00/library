package viewPackage;

import controllerPackage.StatisticController;
import exceptionPackage.BookCountException;
import exceptionPackage.BookNotFoundException;
import exceptionPackage.DivisionException;
import modelPackage.StatisticCategoryTableModel;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class StatisticPanel extends JPanel {
    private JTable resultTable;
    private StatisticController statisticController;
    private JButton updateButton;

    public StatisticPanel(String user) {
        statisticController = new StatisticController();
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        JLabel titleLabel = new JLabel("STATISTIQUE POUR CHAQUE CATEGORIE DE LIVRE");
        titleLabel.setForeground(Color.BLUE);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 11));
        this.add(titleLabel, gbc);
        JLabel underTitleLabel = new JLabel("pour l'année courant, vous pouvez voir le pourcentage par categorie des livrés que vous avez loués");
        underTitleLabel.setForeground(Color.BLUE);
        underTitleLabel.setFont(new Font("Arial", Font.BOLD, 11));
        this.add(underTitleLabel, gbc);

        resultTable = new JTable();
        JScrollPane scrollPane = new JScrollPane(resultTable);
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        this.add(scrollPane, gbc);

        updateButton = new JButton("Actualiser");
        gbc.gridx = 0;
        gbc.gridy = 10;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        add(updateButton, gbc);
        updateStatistic(user);
        updateButton.addActionListener(e -> {
            updateStatistic(user);
        });
    }
    private void updateStatistic(String user){
        ArrayList<StatisticCategoryTableModel> statisticModel = null;
        try {
            statisticModel = statisticController.calculateCategoryPercentageForUser(user);
        } catch (BookCountException exception) {
            JOptionPane.showMessageDialog(null, exception.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } catch (DivisionException exception) {
            JOptionPane.showMessageDialog(null, exception.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        resultTable.setModel(new StatisticTableModel(statisticModel));
    }
}
