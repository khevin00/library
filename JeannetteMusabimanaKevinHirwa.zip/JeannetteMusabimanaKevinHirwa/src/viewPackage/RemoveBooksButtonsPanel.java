package viewPackage;

import controllerPackage.CRUDController;
import modelPackage.BookAdminModel;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class RemoveBooksButtonsPanel extends JPanel {

    private CRUDController controller;
    private Container frameContainer;
    private AdminPanel adminPanel;
    private CRUDAllBooksPanel crudAllBooksPanel;

    public RemoveBooksButtonsPanel(CRUDAllBooksPanel crudAllBooksPanel){
        this.setLayout(new GridLayout(1,2));
        this.crudAllBooksPanel = crudAllBooksPanel;
        this.frameContainer = frameContainer;
        JButton submitButton = new JButton("Remove");
        JButton backButton = new JButton("Back");
        setController(new CRUDController());


        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    BookAdminModel[] selectedBooks = crudAllBooksPanel.getSelectedBooks();
                    if (selectedBooks.length == 0) {
                        JOptionPane.showMessageDialog(null, "Veuillez sélectionner au moins un livre à supprimer.", "Aucun livre sélectionné", JOptionPane.WARNING_MESSAGE);
                    }

                    int response = JOptionPane.showConfirmDialog(null, "Êtes-vous sûr de vouloir supprimer les livres sélectionnés ?", "Confirmation de suppression", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
                    if (response == JOptionPane.YES_OPTION) {
                        for (BookAdminModel book : selectedBooks) {
                            controller.removeBook(book.getIsbn());
                        }
                        JOptionPane.showMessageDialog(null, "Livres supprimés avec succès.", "Suppression effectuée", JOptionPane.INFORMATION_MESSAGE);
                        crudAllBooksPanel.refreshBooksList();
                    }
                } catch (Exception exception) {
                    JOptionPane.showMessageDialog(null, exception.getMessage(), exception.getClass().getSimpleName(), JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameContainer.removeAll();
                frameContainer.revalidate();
                RemoveBooksButtonsPanel.this.removeAll();
                frameContainer.add(adminPanel);
                frameContainer.repaint();
            }
        });
        this.add(backButton);
        this.add(submitButton);
    }
    public void setController(CRUDController controller){
        this.controller = controller;
    }
}
