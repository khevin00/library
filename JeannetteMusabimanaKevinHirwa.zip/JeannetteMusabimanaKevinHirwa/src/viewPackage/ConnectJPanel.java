package viewPackage;

import controllerPackage.LoginController;
import controllerPackage.UserConnectionController;
import exceptionPackage.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import modelPackage.UserModel;

public class ConnectJPanel extends JPanel {
    private JLabel labelUsername, labelPassword;
    private JTextField usernameField;
    private  JPasswordField passwordField;
    private  JButton connectButton;
    private UserConnectionController userController;
    private LoginController loginController;
    private String passwordString, username;

    public ConnectJPanel(){
        this.loginController = loginController;
        this.setBounds(300,300,500,400);
        this.setLayout(new GridBagLayout());
        GridBagConstraints c1 = new GridBagConstraints();
        c1.insets = new Insets(5,5,5,5);
        c1.fill = GridBagConstraints.HORIZONTAL;

        c1.gridx = 0; c1.gridy = 0;
        labelUsername  = new JLabel("Nom d'utilisateur*");
        this.add(labelUsername, c1);

        c1.gridx = 1; c1.gridy = 0;
        usernameField = new JTextField(20);
        this.add(usernameField, c1);

        c1.gridx = 0; c1.gridy = 1;
        labelPassword = new JLabel("Mot de passe");
        this.add(labelPassword, c1);

        c1.gridx = 1; c1.gridy = 1;
        passwordField = new JPasswordField(20);
        this.add(passwordField,c1);

        c1.gridx = 0; c1.gridy = 2;
        c1.gridwidth = 2;
        c1.fill = GridBagConstraints.NONE;
        c1.anchor = GridBagConstraints.SOUTH;
        connectButton = new JButton("Se connecter");
        this.add(connectButton, c1);
        connectButton.addActionListener(new ConnectListener());
    }

    public class ConnectListener implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                char[] password = passwordField.getPassword();
                passwordString = new String(password);
                username = usernameField.getText();

                if(username.isEmpty() && passwordString.isEmpty()){
                    throw new FillAllException("Veillez remplir tout les champs.");
                }
                if(username.isEmpty()){
                    throw new FillAllException("Le nom d'utilisateur ne peut pas être vide.");
                }
                if(passwordString.isEmpty()){
                    throw new FillAllException("Le mot de passe ne peut pas être vide.");
                }

                userController = new UserConnectionController();
                if (userController.userConnection(username, passwordString)) {
                    UserJFrame user = new UserJFrame(new UserModel(username, passwordString));
                    usernameField.setText("");
                    passwordField.setText("");
                } else {
                    usernameField.setText("");
                    passwordField.setText("");
                    JOptionPane.showMessageDialog(null, "Échec de la connexion. Veuillez vérifier vos identifiants.", "Erreur de connexion", JOptionPane.ERROR_MESSAGE);
                }
            }
            catch (FillAllException | ConnectionException exception) {
            JOptionPane.showMessageDialog(null, exception.getMessage(), "Erreur d'enregistrement", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
