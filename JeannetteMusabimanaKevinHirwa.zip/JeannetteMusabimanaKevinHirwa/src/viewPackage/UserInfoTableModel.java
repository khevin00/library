package viewPackage;

import modelPackage.BorrowDisplayModel;
import javax.swing.table.AbstractTableModel;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class UserInfoTableModel extends AbstractTableModel {
    private ArrayList<String> columnNames;
    private ArrayList<BorrowDisplayModel> contents;

    public UserInfoTableModel(ArrayList<BorrowDisplayModel> model){
        columnNames = new ArrayList<>();
        columnNames.add("Nom d'utilisateur");
        columnNames.add("Titre du livre");
        columnNames.add("Nom de l'auteur");
        columnNames.add("Date de location");
        columnNames.add("Maison de publication");
        setContents(model);
    }

    public void setContents(ArrayList<BorrowDisplayModel> contents) {
        this.contents = contents;
    }

    public int getColumnCount() {return columnNames.size();}

    public int getRowCount(){return contents.size();}

    public String getColumnName(int column){return columnNames.get((column));}

    public Object getValueAt(int row,int column){
        BorrowDisplayModel model = contents.get(row);
        switch (column){
            case 0 : return model.getUsername();
            case 1 : return model.getTitleBook();
            case 2 : return model.getAuthorName();
            case 3 : return model.getBorrowDate().format(DateTimeFormatter.ofPattern("dd-MM-YYYY"));
            case 4 : return model.getPublishingName();
            default : return null;
        }
    }

    public Class getColumnClass(int column){
        Class c;
        switch (column){
            case 0 : c = String.class;
                break;
            case 1 : c = String.class;
                break;
            case 2 : c = String.class;
                break;
            case 3 : c = LocalDate.class;
                break;
            case 4 : c = String.class;
                break;
            default : c = String.class;
        }
        return c;
    }
}
