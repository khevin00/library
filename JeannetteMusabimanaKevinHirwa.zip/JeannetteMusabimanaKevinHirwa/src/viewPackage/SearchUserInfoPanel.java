package viewPackage;

import controllerPackage.AuthorSearchController;
import exceptionPackage.ErrorAccesException;
import modelPackage.BorrowDisplayModel;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;

public class SearchUserInfoPanel extends JPanel {
    private JComboBox usersComboBox;
    private JButton searchButton;
    private JTable resultsTable;
    private DefaultTableModel tableModel;
    private AuthorSearchController authorSearchController;

    public SearchUserInfoPanel() {
        authorSearchController = new AuthorSearchController();

        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;

        JLabel titleLabel = new JLabel("Chercher un utilisateur");
        titleLabel.setForeground(Color.BLUE);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 15));
        add(titleLabel, gbc);
        gbc.gridy++;
        usersComboBox = new JComboBox<>();
        usersComboBox.setMaximumRowCount(3);
        try {
            for (String username : authorSearchController.getAllUsers()) {
                usersComboBox.addItem(username);
            }
        } catch (ErrorAccesException exception) {
            JOptionPane.showMessageDialog(this, exception.getMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
        }
        this.add(usersComboBox, gbc);

        searchButton = new JButton("Rechercher");
        gbc.gridx = 0;
        gbc.gridy++;
        gbc.gridwidth = 2;
        add(searchButton, gbc);

        gbc.gridy++;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        resultsTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(resultsTable);
        this.add(scrollPane, gbc);

        searchButton.addActionListener(e -> performSearch());
    }

    private void performSearch() {
        String userName = (String) usersComboBox.getSelectedItem();
        try {
            ArrayList<BorrowDisplayModel> searchModel = authorSearchController.displayBorrowUserSearch(userName);
            resultsTable.setModel(new UserInfoTableModel(searchModel));
        } catch (ErrorAccesException exception) {
            JOptionPane.showMessageDialog(this, "Erreur lors de la recherche", "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }
}
