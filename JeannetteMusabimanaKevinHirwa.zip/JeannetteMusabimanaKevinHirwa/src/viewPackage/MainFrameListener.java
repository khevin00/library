package viewPackage;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class MainFrameListener extends WindowAdapter {
    // appelle à une classe abstract deja existant pour redefinir le windowClosing()
    public void windowClosing( WindowEvent e) {
        System.exit(0);
    }
}

