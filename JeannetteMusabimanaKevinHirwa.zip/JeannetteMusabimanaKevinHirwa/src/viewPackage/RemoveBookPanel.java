package viewPackage;

import javax.swing.*;
import java.awt.*;

public class RemoveBookPanel extends JPanel {
    private RemoveBooksButtonsPanel removeBooksButtonsPanel;
    private CRUDAllBooksPanel crudAllBooksPanel;
    private Container frameContainer;

    public RemoveBookPanel(Container frameContainer){
        this.setBounds(120,120,450,350);
        this.setLayout(new BorderLayout());
        this.frameContainer = frameContainer;
        crudAllBooksPanel = new CRUDAllBooksPanel(frameContainer);
        removeBooksButtonsPanel = new RemoveBooksButtonsPanel(crudAllBooksPanel);
        this.add(crudAllBooksPanel,BorderLayout.CENTER);
        this.add(removeBooksButtonsPanel,BorderLayout.SOUTH);
    }
}