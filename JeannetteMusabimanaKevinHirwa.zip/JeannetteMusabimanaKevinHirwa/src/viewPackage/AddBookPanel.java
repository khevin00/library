package viewPackage;
import javax.swing.*;
import java.awt.*;

public class AddBookPanel extends JPanel {
    private AddBookBottonsPanel addBookBottonsPanel;
    private BookFormPanel bookFormPanel;
    private AdminPanel username;

    public AddBookPanel(AdminPanel username) {
        this.setBounds(110,110,550,410);
        this.setLayout(new BorderLayout());
        this.username = username;
        bookFormPanel = new BookFormPanel();
        addBookBottonsPanel = new AddBookBottonsPanel(bookFormPanel,username);

        this.add(bookFormPanel,BorderLayout.CENTER);
        this.add(addBookBottonsPanel,BorderLayout.SOUTH);
    }
}