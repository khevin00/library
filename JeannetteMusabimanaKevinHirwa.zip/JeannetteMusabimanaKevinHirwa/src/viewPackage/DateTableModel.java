package viewPackage;

import modelPackage.SearchDateModel;
import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;

public class DateTableModel extends AbstractTableModel {
    private ArrayList<String> columnNames;
    private ArrayList<SearchDateModel> contents;

    public DateTableModel(ArrayList<SearchDateModel> authors){
        columnNames = new ArrayList<>();
        columnNames.add("Titre");
        columnNames.add("Auteur");
        columnNames.add("Maison de publication");
        setContents(authors);
    }

    public void setContents(ArrayList<SearchDateModel> contents) {
        this.contents = contents;
    }

    public int getColumnCount() {return columnNames.size();}

    public int getRowCount(){return contents.size();}

    public String getColumnName(int column){return columnNames.get((column));}

    public Object getValueAt(int row,int column){
        SearchDateModel authors = contents.get(row);
        switch (column){
            case 0 : return authors.getTitle();
            case 1 : return authors.getAuthor();
            case 2 : return authors.getPublishingHouse();
            default : return null;
        }
    }

    public Class getColumnClass(int column){
        Class c;
        switch (column){
            case 0 : c = String.class;
                break;
            case 1 : c = String.class;
                break;
            case 2 : c = String.class;
                break;
            default : c = String.class;
        }
        return c;
    }
}
