package viewPackage;

import controllerPackage.CRUDController;
import exceptionPackage.*;
import modelPackage.BookAdminModel;
import modelPackage.PublishingHouseAdminModel;
import modelPackage.AuthorAdminModel;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.util.List;

public class ModifyBookButtonsPanel extends JPanel {
    private CRUDController controller;
    private BookFormModifyPanel bookFormModifyPanel;
    private List<BookAdminModel> books;
    private List<PublishingHouseAdminModel> publishingHouses;
    private List<AuthorAdminModel> authors;

    public ModifyBookButtonsPanel(BookFormModifyPanel bookFormModifyPanel) {
        setLayout(new BorderLayout());
        try {
            controller = new CRUDController();
            books = controller.getAllBooks();
            publishingHouses = controller.getAllPublishingHouses();
            authors = controller.getAllAuthors();
            this.bookFormModifyPanel = new BookFormModifyPanel(books, publishingHouses, authors);
            add(this.bookFormModifyPanel, BorderLayout.CENTER);
        } catch (Exception  e) {
            JOptionPane.showMessageDialog(this, "Erreur : " + e.getMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
        }
            JButton updateButton = new JButton("Mettre à jour le livre");
            updateButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    BookAdminModel book = ModifyBookButtonsPanel.this.bookFormModifyPanel.getBookFromFields();
                    try {
                        if (controller.ckeckTitleExist(book.getTitle())) {
                            JOptionPane.showMessageDialog(null, "le titre que vous avez donné, existe déjà !", "ATTENTION", JOptionPane.WARNING_MESSAGE);
                        }
                        if (book.getPublicationDate().isAfter(LocalDate.now())) {
                            throw new BookAdminModelPublicationDateInFutureException("La date de publication ne peut pas dépasser la date d'aujourd'hui");
                        }
                        if (book.getTitle() == null) {
                            throw new BookAdminModelTitleNullException("Le titre du livre ne peut pas être null");
                        }
                        if(book.getTitle().length() > 50){
                            throw new BookAdminModelTitleLengthException("le titre ne peut pas dépasser 50 caractères");
                        }
                        if (book.getNbCopies() == null) {
                                throw new BookAdminModelNbCopiesNullException("Le nombre de copies ne peut pas être vide");
                        }
                        if (book.getNbCopies() < 0) {
                            throw new BookAdminModelNbCopiesNegatifException("Le nombre de copies ne peut pas être négatif");
                        }
                        if (book.getCategory() != null && book.getCategory().length() > 30) {
                            throw new BookAdminModelCategoryLengthException("La taille de catégorie dépasse la taille allouée dans la base de données");
                        }
                        if(book.getNbCopies() == 0 && book.getIsAvailable() || book.getNbCopies() > 0 && !book.getIsAvailable()){
                            throw new BookAdminModelIsAvailableException("Veillez regler le problème de nombre de copies");
                        }
                        controller.alterBook(book);
                        JOptionPane.showMessageDialog(ModifyBookButtonsPanel.this, "Livre mis à jour avec succès");
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(null, "Erreur de mise à jour " + ex.getMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
                    }
                }
            });
            add(updateButton, BorderLayout.SOUTH);
    }
}