package viewPackage;
import controllerPackage.*;
import modelPackage.UserModel;

import javax.swing.*;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;

public class MainFrame extends JFrame implements LoginSuccessListener {
    private JMenuBar menuBar;
    private JMenu application, user;
    private JMenuItem exit, registration, connect, home, admin;
    private PanelContext panelContext;
    private ExitListener exitListener;

    public MainFrame(){
        panelContext = new PanelContext();
        setBounds(100,100,500,500);
        panelContext.setCurrentState(new WelcomeState());
        setNewPanel(panelContext.getPanel());

        menuBar = new JMenuBar();
        setJMenuBar(menuBar);

        application = new JMenu("application");
        user = new JMenu("utilisateur");

        home = new JMenuItem("Accueil");
        home.addActionListener(e -> {
            panelContext.setCurrentState(new WelcomeState());
            setNewPanel(panelContext.getPanel());
        });
        application.add(home);

        admin = new JMenuItem("administrateur");
        admin.addActionListener(e -> {
            panelContext.setCurrentState(new AdminState());
            setNewPanel(panelContext.getPanel());
        });
        application.add(admin);

        exit = new JMenuItem("Quitter");
        exit.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, InputEvent.CTRL_MASK));
        exitListener = new ExitListener();
        exit.addActionListener(exitListener);
        application.add(exit);
        registration = new JMenuItem("Inscription");
        registration.addActionListener(e -> {
            panelContext.setCurrentState(new RegistrationState());
            setNewPanel(panelContext.getPanel());
        });
        user.add(registration);

        connect = new JMenuItem("Connexion");
        user.add(connect);
        connect.addActionListener(e -> {
            panelContext.setCurrentState(new ConnectState());
            setNewPanel(panelContext.getPanel());

        });

        menuBar.add(application);
        menuBar.add(user);
        this.addWindowListener(new MainFrameListener());
        setVisible(true);
    }

    private void setNewPanel(JPanel newPanel) {
        // s'il y a un panneau, il l'enleve
        if (getContentPane().getComponentCount() > 0) {
            getContentPane().remove(0);
        }
        getContentPane().add(newPanel);
        revalidate();
        repaint();
    }
    public void onLoginSuccess() {
        this.dispose();
    }
}
