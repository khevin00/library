package viewPackage;

import modelPackage.UserModel;
import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class UserJFrame extends JFrame {
    private JMenuBar menuBar;
    private JMenu searchMenu, bookRentalMenu;
    private JMenuItem authorItem, publishingHouseItem, userItem, dateItem, rentOutItem, statisticItem;
    private UserModel user;
    public UserJFrame(UserModel userModel) {
        this.user = userModel;
        setTitle("User Interface");
        setSize(500, 320);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        initMenuBar();
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                handleWindowClosing();
            }
        });
        setVisible(true);
    }

    private void initMenuBar() {
        menuBar = new JMenuBar();
        setJMenuBar(menuBar);

        searchMenu = new JMenu("Recherche");
        menuBar.add(searchMenu);

        authorItem = createMenuItem("Auteur", new SearchAuthorPanel());
        userItem = createMenuItem("Utilisateur", new SearchUserInfoPanel());
        dateItem = createMenuItem("Date", new SearchDatePanel());

        bookRentalMenu = new JMenu("Louer/rendre");
        menuBar.add(bookRentalMenu);

        rentOutItem = createMenuBookItem("Louer un livre", new BookRentalPanel(user.getUsername()));
        statisticItem = createMenuBookItem("Statistique", new StatisticPanel(user.getUsername()));
    }

    private JMenuItem createMenuItem(String title, JPanel panel) {
        JMenuItem menuItem = new JMenuItem(title);
        menuItem.addActionListener(e -> displayPanel(panel));
        searchMenu.add(menuItem);
        return menuItem;
    }
    private JMenuItem createMenuBookItem(String title, JPanel panel) {
        JMenuItem menuItem = new JMenuItem(title);
        menuItem.addActionListener(e -> displayPanel(panel));
        bookRentalMenu.add(menuItem);
        return menuItem;
    }
    private void displayPanel(JPanel panel) {
        Container frameContainer = getContentPane();
        frameContainer.removeAll();
        frameContainer.add(panel, BorderLayout.CENTER);
        frameContainer.revalidate();
        frameContainer.repaint();
    }
    private void handleWindowClosing() {
        int answer = JOptionPane.showConfirmDialog(this, "Êtes-vous sûr le point de vous déconnecter ?", "Confirmer la déconnexion", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (answer == JOptionPane.YES_OPTION) {
            dispose();
        }
    }
}
