package viewPackage;

import controllerPackage.CRUDController;
import modelPackage.AuthorAdminModel;
import modelPackage.BookAdminModel;
import modelPackage.PublishingHouseAdminModel;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class BookFormPanel extends JPanel {

    private CRUDController controller;
    private JLabel isbnLabel, publicationDateLabel,titleLabel, nbCopiesLabel,categoryLabel, isAvailableLabel, illustratedLabel, publicationHouseLabel, authorWritingLabel;
    private JTextField isbn,title, nbCopies,category;
    private JRadioButton isAvailableYes;
    private JRadioButton isAvailableNo;
    private JRadioButton illustratedYes;
    private JRadioButton illustratedNo;
    private JSpinner publicationDateSpinner;
    private JSpinner.DateEditor publicationDateEditor;
    private JComboBox publishingHouseComboBox,authorWritingComboBox;

    private ArrayList<BookAdminModel> books;
    private ArrayList<PublishingHouseAdminModel> publishingHouses;
    private ArrayList<AuthorAdminModel> authors;
    private PublishingHouseAdminModel [] publishingHousesList;
    private AuthorAdminModel [] authorsList;

    public BookFormPanel(){
        setController(new CRUDController());
        GridBagLayout layout = new GridBagLayout();
        this.setLayout(layout);
        GridBagConstraints gbc = new GridBagConstraints();
        try {
            books = controller.getAllBooks();
            publishingHouses = controller.getAllPublishingHouses();
            authors = controller.getAllAuthors();
            publishingHousesList = new PublishingHouseAdminModel[publishingHouses.size()];
            authorsList = new AuthorAdminModel[authors.size()];

            isbnLabel = new JLabel("Isbn");
            publicationDateLabel = new JLabel("Date de publication");
            titleLabel = new JLabel("Title");
            nbCopiesLabel = new JLabel(" Nombre de copies");
            categoryLabel = new JLabel("Catégorie");
            isAvailableLabel = new JLabel("Est-il disponibilité?");
            illustratedLabel = new JLabel("Est-il illustré");
            publicationHouseLabel = new JLabel("Maison d'édition");
            authorWritingLabel = new JLabel("Auteur");

            gbc.fill = GridBagConstraints.HORIZONTAL;
            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.insets = new Insets(14,95,16,112);
            layout.setConstraints(isbnLabel,gbc);
            this.add(isbnLabel);

            gbc.gridx = 0;
            gbc.gridy = 1;
            this.add(publicationDateLabel,gbc);

            gbc.gridx = 0;
            gbc.gridy = 2;
            this.add(titleLabel,gbc);

            gbc.gridx = 0;
            gbc.gridy = 3;
            this.add(nbCopiesLabel,gbc);

            gbc.gridx = 0;
            gbc.gridy = 4;
            this.add(categoryLabel,gbc);

            gbc.gridx = 0;
            gbc.gridy = 5;
            this.add(isAvailableLabel,gbc);

            gbc.gridx = 0;
            gbc.gridy = 6;
            this.add(illustratedLabel,gbc);

            gbc.gridx = 0;
            gbc.gridy = 7;
            this.add(publicationHouseLabel,gbc);

            gbc.gridx = 0;
            gbc.gridy = 8;
            this.add(authorWritingLabel,gbc);

            isbn = new JTextField();
            title = new JTextField();
            nbCopies = new JTextField();
            category = new JTextField();

            gbc.gridx = 1;
            gbc.gridy = 0;
            gbc.insets = new Insets(6,6,6,6);
            isbn.setPreferredSize(new Dimension(152,24));
            this.add(isbn,gbc);


            gbc.gridx = 1;
            gbc.gridy = 2;
            isbn.setPreferredSize(new Dimension(152,24));
            this.add(title,gbc);

            gbc.gridx = 1;
            gbc.gridy = 3;
            isbn.setPreferredSize(new Dimension(152,24));
            this.add(nbCopies,gbc);

            gbc.gridx = 1;
            gbc.gridy = 4;
            isbn.setPreferredSize(new Dimension(152,24));
            this.add(category,gbc);

            isAvailableYes = new JRadioButton("Oui");
            isAvailableNo = new JRadioButton("Non");
            ButtonGroup isAvailableGroup = new ButtonGroup();
            isAvailableGroup.add(isAvailableYes);
            isAvailableGroup.add(isAvailableNo);

            JPanel isAvailablePanel = new JPanel();
            isAvailablePanel.add(isAvailableYes);
            isAvailablePanel.add(isAvailableNo);
            gbc.gridx = 1;
            gbc.gridy = 5;
            add(isAvailablePanel,gbc);

            illustratedYes = new JRadioButton("Oui");
            illustratedNo = new JRadioButton("Non");
            ButtonGroup illustratedGroup = new ButtonGroup();
            illustratedGroup .add(illustratedYes);
            illustratedGroup .add(illustratedNo);

            JPanel illustratedPanel = new JPanel();
            illustratedPanel.add(illustratedYes);
            illustratedPanel.add(illustratedNo);
            gbc.gridx = 1;
            gbc.gridy = 6;
            add(illustratedPanel,gbc);

            publicationDateSpinner = new JSpinner(new SpinnerDateModel());
            publicationDateEditor = new JSpinner.DateEditor(publicationDateSpinner,"dd-MM-yyyy");
            publicationDateSpinner.setEditor(publicationDateEditor);
            gbc.gridx = 1;
            gbc.gridy = 1;
            this.add(publicationDateSpinner,gbc);

            publishingHouseComboBox = new JComboBox<PublishingHouseAdminModel>();
            publishingHouseComboBox.setMaximumRowCount(4);
            int i = 0;
            for( PublishingHouseAdminModel publishingName: publishingHouses){
                publishingHousesList[i] = publishingName;
                publishingHouseComboBox.addItem(publishingName.getPublishingName());
                i++;
            }
            gbc.gridx = 1;
            gbc.gridy = 7;
            this.add(publishingHouseComboBox,gbc);

            authorWritingComboBox = new JComboBox<AuthorAdminModel>();
            authorWritingComboBox.setMaximumRowCount(4);
            int k = 0;
            for(AuthorAdminModel firstName : authors){
                authorsList[k] = firstName;
                authorWritingComboBox.addItem(firstName.toString());
                k++;
            }
            gbc.gridx = 1;
            gbc.gridy = 8;
            this.add(authorWritingComboBox,gbc);

        }catch (Exception exception){
            JOptionPane.showMessageDialog(null, exception.getMessage(), exception.getClass().getSimpleName(),JOptionPane.ERROR_MESSAGE);
        }
    }
    public void setController(CRUDController controller){
        this.controller = controller;
    }
    public JTextField getIsbn(){
        return isbn;
    }
    public  JTextField getTitle(){
        return title;
    }
    public JTextField getNbCopies(){
        return  nbCopies;
    }
    public JTextField getCategory(){
        return category;
    }
    public JSpinner getPublicationDateSpinner(){
        return publicationDateSpinner;
    }
    public JSpinner.DateEditor getPublicationDateEditor(){
        return publicationDateEditor;
    }
    public JRadioButton getIsAvailableYes(){
        return isAvailableYes;
    }
    public JRadioButton getIsAvailableNo(){
        return isAvailableNo;
    }

    public JRadioButton getIllustratedYes(){
        return illustratedYes;
    }

    public JRadioButton getIllustratedNo(){
        return illustratedNo;
    }

    public JComboBox getAuthorWritingComboBox(){
        return authorWritingComboBox;
    }
    public PublishingHouseAdminModel[] getPublishingHousesList(){
        return publishingHousesList;
    }
    public AuthorAdminModel[] getAuthorsList(){
        return authorsList;
    }
    public JComboBox getPublishingHouse(){
        return publishingHouseComboBox;
    }

}