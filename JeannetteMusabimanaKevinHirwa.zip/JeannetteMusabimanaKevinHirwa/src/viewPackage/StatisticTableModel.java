package viewPackage;

import modelPackage.StatisticCategoryTableModel;
import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;

public class StatisticTableModel extends AbstractTableModel {
    private ArrayList<String> columnNames;
    private ArrayList<StatisticCategoryTableModel> contents;

    public StatisticTableModel(ArrayList<StatisticCategoryTableModel> category){
        columnNames = new ArrayList<>();
        columnNames.add("Categorie");
        columnNames.add("Pourcentage");
        setContents(category);
    }

    public void setContents(ArrayList<StatisticCategoryTableModel> contents) {
        this.contents = contents;
    }

    public int getColumnCount() {return columnNames.size();}

    public int getRowCount(){return contents.size();}

    public String getColumnName(int column){return columnNames.get((column));}

    public Object getValueAt(int row,int column){
        StatisticCategoryTableModel category = contents.get(row);
        switch (column){
            case 0 : return category.getCategoryName();
            case 1 : return category.getPercentage();
            default : return null;
        }
    }

    public Class getColumnClass(int column){
        Class c;
        switch (column){
            case 0 : c = String.class;
                break;
            case 1 : c = Double.class;
                break;
            default : c = String.class;
        }
        return c;
    }
}
