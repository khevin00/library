package viewPackage;

import controllerPackage.AuthorSearchController;
import exceptionPackage.ErrorAccesException;
import exceptionPackage.FillAllException;
import exceptionPackage.DateException;
import modelPackage.SearchDateModel;
import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;

public class SearchDatePanel extends JPanel {
    private JButton searchButton;
    private JSpinner firstDateSpinner, secondDateSpinner;
    private JLabel firstDateLabel,secondDateLabel;
    private JTable resultTable;
    private AuthorSearchController authorSearchController;

    public SearchDatePanel(){
        authorSearchController = new AuthorSearchController();
        searchButton = new JButton("rechercher");
        firstDateSpinner = new JSpinner();
        secondDateSpinner = new JSpinner();

        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        JLabel titleLabel = new JLabel("Recherche des informations de livres avec une date.");
        titleLabel.setForeground(Color.BLUE);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 15));
        this.add(titleLabel, gbc);

        SpinnerDateModel firstDateModel = new SpinnerDateModel();
        SpinnerDateModel secondDateModel = new SpinnerDateModel();
        firstDateSpinner = new JSpinner(firstDateModel);
        secondDateSpinner = new JSpinner(secondDateModel);
        JSpinner.DateEditor firstDateEditor = new JSpinner.DateEditor(firstDateSpinner, "dd-MM-yyyy");
        JSpinner.DateEditor secondDateEditor = new JSpinner.DateEditor(secondDateSpinner, "dd-MM-yyyy");
        firstDateSpinner.setValue(new Date());
        secondDateSpinner.setValue(new Date());
        firstDateLabel = new JLabel("Première date ");
        this.add(firstDateLabel);
        add(firstDateSpinner, gbc);

        secondDateLabel = new JLabel("Deuxième date ");
        this.add(secondDateLabel);
        add(secondDateSpinner, gbc);

        firstDateSpinner.setEditor(firstDateEditor);
        secondDateSpinner.setEditor(secondDateEditor);
        add(searchButton, gbc);
        resultTable = new JTable();

        JScrollPane scrollPane = new JScrollPane(resultTable);
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        this.add(scrollPane, gbc);
        searchButton.addActionListener(e -> {
            try {
                performSearch();
            } catch (FillAllException | DateException exception) {
                JOptionPane.showMessageDialog(null, exception.getMessage()," Error", JOptionPane.ERROR_MESSAGE);
            }
        });

    }
    private void performSearch() throws FillAllException, DateException {
        LocalDate firstSelectedDate = ((Date)firstDateSpinner.getValue()).toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        LocalDate secondSelectedDate = ((Date)secondDateSpinner.getValue()).toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        if (firstSelectedDate != null) {
            try {
                ArrayList<SearchDateModel> dateInfos = authorSearchController.getInformationsWithDate(firstSelectedDate, secondSelectedDate);

                if (dateInfos.isEmpty()) {
                    throw new ErrorAccesException("La date sélectionnée n'a obtenu aucun résultat.");
                }
                resultTable.setModel(new DateTableModel(dateInfos));

            } catch (ErrorAccesException exception) {
                JOptionPane.showMessageDialog(null, exception.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            throw new FillAllException("Veuillez remplir le champ de date correctement.");
        }
    }
}
