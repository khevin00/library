package viewPackage;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class AdminCRUDFrame extends JFrame {
    private Container frameContainer;
    private JMenuBar menuBar;
    private AddBookPanel addBookPanel;
    private RemoveBookPanel removeBookPanel;
    private ModifyBookPanel modifyBookPanel;
    private CRUDAllBooksPanel crudAllBooksPanel;
    private AdminPanel adminPanel;
    private JMenu adiminstratorMenu;
    private JMenuItem displayAllBooks, addBook, removeBook, modifyBook, disconnection;
    private MainFrame mainFrame;

    public AdminCRUDFrame(){
        frameContainer = this.getContentPane();
        this.adminPanel = adminPanel;
        this.setLayout(new FlowLayout());
        setBounds(120,120,800,600);

        menuBar = new JMenuBar();
        setJMenuBar(menuBar);

        adiminstratorMenu = new JMenu("CRUD");
        menuBar.add(adiminstratorMenu);

        displayAllBooks = new JMenuItem("Affichages des livres");
        addBook = new JMenuItem("Ajout d'un livre");
        removeBook = new JMenuItem("Supression d'un livre");
        modifyBook = new JMenuItem("Modification d'un livre");
        disconnection = new JMenuItem("Deconnexion");

        adiminstratorMenu.add(displayAllBooks);
        adiminstratorMenu.add(addBook);
        adiminstratorMenu.add(removeBook);
        adiminstratorMenu.add(modifyBook);
        adiminstratorMenu.add(disconnection);

        setJMenuBar(menuBar);

        this.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent event){
                dispose();
                mainFrame = new MainFrame();
                mainFrame.setVisible(true);
            }
        });
        disconnection.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                mainFrame = new MainFrame();
                mainFrame.setVisible(true);
            }
        });
        displayAllBooks.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                crudAllBooksPanel = new CRUDAllBooksPanel(frameContainer);
                frameContainer.removeAll();
                frameContainer.revalidate();
                frameContainer.setLayout(new BorderLayout());
                frameContainer.add(crudAllBooksPanel,BorderLayout.CENTER);
                frameContainer.repaint();

            }
        });
        addBook.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addBookPanel = new AddBookPanel(adminPanel);
                frameContainer.removeAll();
                frameContainer.revalidate();
                frameContainer.setLayout(new BorderLayout());
                frameContainer.add(addBookPanel, BorderLayout.CENTER);
                frameContainer.repaint();
            }
        });
        modifyBook.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                modifyBookPanel = new ModifyBookPanel(frameContainer);
                frameContainer.removeAll();
                frameContainer.revalidate();
                frameContainer.setLayout(new BorderLayout());
                frameContainer.add(modifyBookPanel,BorderLayout.CENTER);
                frameContainer.repaint();
            }
        });
        removeBook.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                removeBookPanel = new RemoveBookPanel(frameContainer);
                frameContainer.removeAll();
                frameContainer.revalidate();
                frameContainer.setLayout(new BorderLayout());
                frameContainer.add(removeBookPanel,BorderLayout.CENTER);
                frameContainer.repaint();
            }
        });
    }

}