package viewPackage;

import controllerPackage.AuthorSearchController;
import exceptionPackage.ErrorAccesException;
import modelPackage.SearchAuthorModel;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class SearchAuthorPanel extends JPanel {
    private JComboBox<String> authorComboBox;
    private JButton searchButton;
    private JTable resultTable;
    private AuthorSearchController authorSearchController;

    public SearchAuthorPanel() {
        authorSearchController = new AuthorSearchController();
        this.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        JLabel titleLabel = new JLabel("Recherche des informations de livres par l'auteur.");
        titleLabel.setForeground(Color.BLUE);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 15));
        this.add(titleLabel, gbc);

        authorComboBox = new JComboBox<>();
        this.add(authorComboBox, gbc);

        searchButton = new JButton("Recherche");
        searchButton.addActionListener(e -> performSearch());
        this.add(searchButton, gbc);

        resultTable = new JTable();
        JScrollPane scrollPane = new JScrollPane(resultTable);
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;

        this.add(scrollPane, gbc);
        populateAuthorComboBox();
    }
    private void performSearch() {
        String selectedAuthor = (String) authorComboBox.getSelectedItem();
        try {
            ArrayList<SearchAuthorModel> authorInfos = authorSearchController.getInformationsAboutAuthor(selectedAuthor);
            resultTable.setModel(new AuthorTableModel(authorInfos));
        } catch (ErrorAccesException exception) {
            JOptionPane.showMessageDialog(null, exception.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    private void populateAuthorComboBox() {
        authorComboBox.removeAllItems();
        try {
            for (String title : authorSearchController.getAllAuthorsNames()) {
                authorComboBox.addItem(title);
            }
        } catch (ErrorAccesException exception) {
            JOptionPane.showMessageDialog(null, exception.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
