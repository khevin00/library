package viewPackage;

import javax.swing.*;
import java.awt.*;

public class ModifyBookPanel extends JPanel {
    private ModifyBookButtonsPanel modifyBookButtonsPanel;
    private BookFormModifyPanel bookFormModifyPanel;
    private Container frameContainer;

    public ModifyBookPanel(Container frameContainer){
        this.setBounds(110,110,550,410);
        this.setLayout(new BorderLayout());
        this.frameContainer = frameContainer;
        bookFormModifyPanel = new BookFormModifyPanel();
        modifyBookButtonsPanel = new ModifyBookButtonsPanel(bookFormModifyPanel);
        this.add(bookFormModifyPanel, BorderLayout.CENTER);
        this.add(modifyBookButtonsPanel, BorderLayout.SOUTH);

    }
}