package viewPackage;

import controllerPackage.AdminAuthController;
import exceptionPackage.ConnectionException;
import exceptionPackage.FillAllException;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AdminPanel extends JPanel {
    private JLabel userLabel, passwordLabel;
    private JTextField userText;
    private JPasswordField password;
    private JButton connectionButton;
    private AdminAuthController adminController;
    private AdminCRUDFrame adminManagerFrame;

    public AdminPanel(){
        this.setLayout(new GridBagLayout());
        this.setBounds(10,80,600,300);
        GridBagConstraints c1 = new GridBagConstraints();
        c1.insets = new Insets(5, 5, 5, 5);
        c1.fill = GridBagConstraints.HORIZONTAL;

        c1.gridx = 0; c1.gridy = 0;
        userLabel = new JLabel("Nom utilisateur :");
        this.add(userLabel,c1);

        c1.gridx = 0; c1.gridy = 1;
        userText = new JTextField(15);
        this.add(userText,c1);

        c1.gridx = 0; c1.gridy = 2;
        passwordLabel = new JLabel("Mot de passe ");
        this.add(passwordLabel,c1);

        c1.gridx = 0; c1.gridy = 3;
        password = new JPasswordField(15);
        this.add(password,c1);

        c1.gridx = 0; c1.gridy = 4;
        c1.gridwidth = 2;
        c1.fill = GridBagConstraints.NONE;
        c1.anchor = GridBagConstraints.SOUTH;
        connectionButton = new JButton("Connecter");
        connectionButton.setBackground(Color.black);
        connectionButton.setForeground(Color.white);
        this.add(connectionButton, c1);
        connectionButton.addActionListener(new AdminListener());
    }

    public class AdminListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            try {
                String username = userText.getText();
                char[] passwordArray = password.getPassword();
                String password = new String(passwordArray);
                if ((username != "") && (password != "")) {
                    adminController = new AdminAuthController();
                    boolean authentication = adminController.connectionAdmin(username, password);
                    if (authentication) {
                        // Ouverture de la nouvelle fenêtre
                        adminManagerFrame = new AdminCRUDFrame();
                        adminManagerFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                        adminManagerFrame.setVisible(true);
                        // Fermeture de la fenêtre actuelle
                        SwingUtilities.getWindowAncestor(AdminPanel.this).dispose();
                    } else {
                        throw new ConnectionException("mot de passe ou nom d'utilisateur erroné ! veuillez réessayer");
                    }
                }else{
                    throw new FillAllException("veillez remplir tout les champs");
                }
            }
            catch (FillAllException | ConnectionException exception) {
                JOptionPane.showMessageDialog(null, exception.getMessage(), "Erreur d'enregistrement", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
