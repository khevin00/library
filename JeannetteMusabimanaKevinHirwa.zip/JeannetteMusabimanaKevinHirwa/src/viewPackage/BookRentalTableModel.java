package viewPackage;

import modelPackage.BookBorrowModel;
import javax.swing.table.AbstractTableModel;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class BookRentalTableModel extends AbstractTableModel {
    private List<String> columnNames;
    private List<BookBorrowModel> contents;

    public BookRentalTableModel(ArrayList<BookBorrowModel> books) {
        columnNames = new ArrayList<>();
        columnNames.add("Date d'emprunt");
        columnNames.add("Title de livre");
        setContents(books);
    }

    private void setContents(ArrayList<BookBorrowModel> books) {
        contents = books;
    }

    @Override
    public int getColumnCount() {
        return columnNames.size();
    }

    @Override
    public int getRowCount() {
        return contents.size();
    }

    @Override
    public String getColumnName(int col) {
        return columnNames.get(col);
    }

    @Override
    public Object getValueAt(int row, int col) {
        BookBorrowModel book = contents.get(row);

        switch (col) {
            case 0:
                return book.getBorrowDate().format(DateTimeFormatter.ofPattern("dd-MM-YYYY"));
            case 1 :
                return book.getTitle();
            default:
                return null;
        }
    }

    @Override
    public Class getColumnClass(int col) {
        Class c;
        switch (col) {
            case 0: c = LocalDate.class;
                break;
            default:
                c = String.class;
        }
        return c;
    }
}
