package viewPackage;

import controllerPackage.CRUDController;
import modelPackage.BookAdminModel;
import javax.swing.*;
import javax.swing.table.TableColumn;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import exceptionPackage.*;
import modelPackage.PublishingHouseAdminModel;
import modelPackage.AuthorAdminModel;

public class CRUDAllBooksPanel extends JPanel {
    private CRUDController controller;
    private List<PublishingHouseAdminModel> publishingHouses;
    private List<AuthorAdminModel> authors;
    private static JTable bookTable;
    private JScrollPane scrollPane;

    TableColumn column;
    private static AllBooksModel allBooksModel;
    private Container frameContainer;

    public CRUDAllBooksPanel(Container frameContainer) {
        this.frameContainer = frameContainer;
        setController(new CRUDController());

        try {
            ArrayList<BookAdminModel> books = controller.getAllBooks();
            publishingHouses = controller.getAllPublishingHouses();
            authors = controller.getAllAuthors();
            allBooksModel = new AllBooksModel(books,publishingHouses,authors);
            bookTable = new JTable(allBooksModel);
            bookTable.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
            bookTable.setRowSelectionAllowed(true);
            scrollPane = new JScrollPane(bookTable);

            column = bookTable.getColumnModel().getColumn(0);
            column.setPreferredWidth(80);
            column = bookTable.getColumnModel().getColumn(1);
            column.setPreferredWidth(120);
            column = bookTable.getColumnModel().getColumn(2);
            column.setPreferredWidth(50);
            column = bookTable.getColumnModel().getColumn(3);
            column.setPreferredWidth(100);
            column = bookTable.getColumnModel().getColumn(4);
            column.setPreferredWidth(90);
            column = bookTable.getColumnModel().getColumn(5);
            column.setPreferredWidth(70);
            column = bookTable.getColumnModel().getColumn(6);
            column.setPreferredWidth(100);
            column = bookTable.getColumnModel().getColumn(7);
            column.setPreferredWidth(100);
            column = bookTable.getColumnModel().getColumn(8);
            column.setPreferredWidth(90);

            JComboBox<PublishingHouseAdminModel> publishingHouseComboBox = new JComboBox<>(publishingHouses.toArray(new PublishingHouseAdminModel[0]));
            bookTable.getColumnModel().getColumn(7).setCellEditor(new DefaultCellEditor(publishingHouseComboBox));

            JComboBox<AuthorAdminModel> authorComboBox = new JComboBox<>(authors.toArray(new AuthorAdminModel[0]));
            bookTable.getColumnModel().getColumn(8).setCellEditor(new DefaultCellEditor(authorComboBox));

            bookTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            this.add(scrollPane);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), ex.getClass().getSimpleName(), JOptionPane.ERROR_MESSAGE);
        }
    }
    public void setController(CRUDController controller){
        this.controller = controller;
    }
    public BookAdminModel[] getSelectedBooks(){
        int[] selectedIndices = new int[]{bookTable.getSelectedRow()};
        BookAdminModel[] selectedBooks = new BookAdminModel[selectedIndices.length];
        for(int i = 0; i < selectedIndices.length; i++){
            selectedBooks[i] = allBooksModel.getBookAt(selectedIndices[i]);
        }
        return selectedBooks;
    }

    public void refreshBooksList() throws ErrorAccesException {
        List<BookAdminModel> updatedBooks = controller.getAllBooks();
        allBooksModel.setBooks(updatedBooks);
        allBooksModel.fireTableDataChanged();
    }


}