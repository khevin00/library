package viewPackage;

import controllerPackage.BookRentalController;
import exceptionPackage.ErrorAccesException;
import modelPackage.BookBorrowModel;
import modelPackage.BookRentalModel;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class BookRentalPanel extends JPanel {
    private JComboBox<String> bookComboBox;
    private JLabel selectedBookCountLabel;
    private JButton rentButton,refreshButton, returnButton;
    private BookRentalController bookRentalController;
    private JTable rentalTable;

    public BookRentalPanel(String user) {
        bookRentalController = new BookRentalController();
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        JLabel title = new JLabel("LOCATION DE LIVRE");
        title.setForeground(Color.RED);
        title.setFont(new Font("Arial", Font.BOLD, 15));
        this.add(title, gbc);

        bookComboBox = new JComboBox<String>();
        this.add(bookComboBox, gbc);
        selectedBookCountLabel = new JLabel("Sélectionnez un livre pour voir les exemplaires disponibles");
        rentButton = new JButton("Louer");
        rentButton.addActionListener(e -> {
            try {
                rentBook(user);
                populateBookCombobox();
            } catch (ErrorAccesException exception) {
                JOptionPane.showMessageDialog(null, exception.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        refreshButton = new JButton("Rafraîchir");
        refreshButton.addActionListener(e -> refreshBookRentalData(user));
        returnButton = new JButton("Rendre le livre");
        returnButton.addActionListener(e -> returnBook(user));

        add(returnButton, gbc);
        add(bookComboBox, gbc);
        add(selectedBookCountLabel, gbc);
        add(rentButton, gbc);
        add(refreshButton, gbc);

        rentalTable = new JTable();

        JScrollPane scrollPane = new JScrollPane(rentalTable);
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        this.add(scrollPane, gbc);

        loadBookRentalData(user);

        populateBookCombobox();
        bookComboBox.addActionListener(e -> {
            try {
                updateBookCount();
            } catch (ErrorAccesException exception) {
                JOptionPane.showMessageDialog(null, exception.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }
    private void returnBook(String user) {
        int selectedRow = rentalTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner un livre à rendre.", "Aucune sélection", JOptionPane.ERROR_MESSAGE);
        }else{
            String title = (String) rentalTable.getValueAt(selectedRow, 1);
            try {
                bookRentalController.returnBook(title);
                String isbn = bookRentalController.getISBN(title);
                bookRentalController.updateCurrentlyRented(user,isbn);
                populateBookCombobox(); // dans le cas où on ajoute un livre qui etait en rupture
                JOptionPane.showMessageDialog(this, "Vous avez rendu : " + title, "Livre rendu", JOptionPane.INFORMATION_MESSAGE);
                refreshBookRentalData(user);
            } catch (ErrorAccesException exception) {
                JOptionPane.showMessageDialog(this, exception.getMessage(), "Erreur de retour", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void populateBookCombobox() {
        bookRentalController = new BookRentalController();
        bookComboBox.removeAllItems();
        try {
            for (BookRentalModel title : bookRentalController.getAllBooks()) {
                if(title.getCopiesAvailable() > 0){
                    bookComboBox.addItem(title.getTitle());
                }
            }
        } catch (ErrorAccesException exception) {
            JOptionPane.showMessageDialog(null, exception.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    private void updateBookCount() throws ErrorAccesException {
        String selectedBook = (String) bookComboBox.getSelectedItem();
        ArrayList<BookRentalModel> books = bookRentalController.getAllBooks();
        for (BookRentalModel book : books) {
            if (book.getTitle().equals(selectedBook)) {
                selectedBookCountLabel.setText("Exemplaires disponibles : " + book.getCopiesAvailable());
            }
        }
    }

    private void rentBook(String user) throws ErrorAccesException {
        String selectedBook = (String) bookComboBox.getSelectedItem();
        boolean isAlreadyRented = bookRentalController.bookAlreadyRented(user, selectedBook);
        if(isAlreadyRented){
            JOptionPane.showMessageDialog(null, "Vous avez déjà loué ce livre", "ERROR", JOptionPane.ERROR_MESSAGE);
        }else{
            bookRentalController.rentalBook(selectedBook);
            bookRentalController.addBookInBorrow(selectedBook,user);
            JOptionPane.showMessageDialog(this, "Vous avez loué : " + selectedBook);
            loadBookRentalData(user);
        }
    }
    private void refreshBookRentalData(String user) {
        loadBookRentalData(user);
    }

    private void loadBookRentalData(String user) {
        try {
            ArrayList<BookBorrowModel> borrowBook = bookRentalController.displayBorrowBook(user);
            rentalTable.setModel(new BookRentalTableModel(borrowBook));
        } catch (ErrorAccesException exception) {
            JOptionPane.showMessageDialog(null, exception.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
