package viewPackage;

import modelPackage.SearchAuthorModel;
import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;

public class AuthorTableModel extends AbstractTableModel {
    private ArrayList<String> columnNames;
    private ArrayList<SearchAuthorModel> contents;

    public AuthorTableModel(ArrayList<SearchAuthorModel> authors){
        columnNames = new ArrayList<>();
        columnNames.add("publicationName");
        columnNames.add("titleBook");
        columnNames.add("localityName");
        setContents(authors);
    }

    public void setContents(ArrayList<SearchAuthorModel> contents) {
        this.contents = contents;
    }

    public int getColumnCount() {return columnNames.size();}

    public int getRowCount(){return contents.size();}

    public String getColumnName(int column){return columnNames.get((column));}

    public Object getValueAt(int row,int column){
        SearchAuthorModel authors = contents.get(row);
        switch (column){
            case 0 : return authors.getPublicationName();
            case 1 : return authors.getTitleBook();
            case 2 : return authors.getLocalityName();
            default : return null;
        }
    }

    public Class getColumnClass(int column){
        Class c;
        switch (column){
            case 0 : c = String.class;
                break;
            case 1 : c = String.class;
                break;
            case 2 : c = String.class;
                break;
            default : c = String.class;
        }
        return c;
    }
}
